package com.osfenix.replayanalyzer;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int PICK_REPLAY = 4201;
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class NativeBridge {
        @JavascriptInterface public void chooseReplay() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-haxball-replay"});
                startActivityForResult(intent, PICK_REPLAY);
            });
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_REPLAY || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            String name = "replay.hbr2";
            try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                if (c != null && c.moveToFirst()) { int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (col >= 0) name = c.getString(col); }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = getContentResolver().openInputStream(uri)) { if (in == null) throw new Exception("No se pudo abrir el archivo"); byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) { out.write(buf, 0, n); if (out.size() > 100 * 1024 * 1024) throw new Exception("Archivo superior a 100 MB"); } }
            byte[] bytes = out.toByteArray();
            StringBuilder hex = new StringBuilder();
            for (int i=0;i<Math.min(bytes.length,9);i++) hex.append(String.format(java.util.Locale.US,"%02x",bytes[i] & 0xff));
            String escapedName = name.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
            String js = "window.importNativeReplay && window.importNativeReplay('"+escapedName+"',"+bytes.length+",'"+hex+"')";
            webView.evaluateJavascript(js, null);
        } catch (Exception e) {
            String msg = e.getMessage() == null ? "Error al leer archivo" : e.getMessage();
            String safe = msg.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
            webView.evaluateJavascript("window.nativeImportError && window.nativeImportError('"+safe+"')", null);
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
