'use strict';
const STORAGE_KEY = 'osfenix-replay-analyzer-history-v1';
const fileInput = document.getElementById('replayFile');
const notice = document.getElementById('notice');
const matchList = document.getElementById('matchList');
const emptyState = document.getElementById('emptyState');
const matchCount = document.getElementById('matchCount');
function readHistory(){try{const v=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');return Array.isArray(v)?v:[]}catch{return []}}
function writeHistory(items){localStorage.setItem(STORAGE_KEY,JSON.stringify(items))}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function showNotice(message,type='success'){notice.className='notice '+type;notice.textContent=message;notice.hidden=false}
function formatBytes(n){if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(2)+' MB'}
function formatDuration(frames){if(!Number.isFinite(frames)||frames<=0)return 'Duración no disponible';const total=Math.floor(frames/60);return `${Math.floor(total/60)}:${String(total%60).padStart(2,'0')}`}
function validateReplay(buffer){if(buffer.byteLength<8)throw new Error('El archivo es demasiado pequeño para ser una repetición HaxBall válida.');const bytes=new Uint8Array(buffer,0,4);const magic=String.fromCharCode(...bytes);if(magic!=='HBR2')throw new Error('La cabecera no coincide con HBR2. Comprueba que sea un archivo de repetición .hbr2 y no otro formato.');const view=new DataView(buffer);const version=view.getUint8(4);let frames=null;if(buffer.byteLength>=9){frames=view.getUint32(5,true);if(frames>60*60*24*30)frames=null;}return {version,frames}}
function render(){const items=readHistory();matchCount.textContent=String(items.length);emptyState.hidden=items.length>0;matchList.innerHTML=items.map(item=>`<article class="match-card"><div class="file-icon">HBR2</div><div class="match-info"><b>${escapeHTML(item.name)}</b><small>${escapeHTML(item.date)} · ${escapeHTML(formatBytes(item.size))} · ${escapeHTML(item.duration)}</small></div><span class="valid-pill">✓ VALIDADO</span><button class="remove-file" type="button" data-remove="${escapeHTML(item.id)}" aria-label="Quitar ${escapeHTML(item.name)} del historial">×</button></article>`).join('');}
fileInput.addEventListener('change',async()=>{const file=fileInput.files&&fileInput.files[0];if(!file)return;try{const buffer=await file.arrayBuffer();const meta=validateReplay(buffer);const items=readHistory();const existing=items.find(x=>x.name===file.name&&x.size===file.size&&x.lastModified===file.lastModified);if(existing){showNotice('Esta repetición ya está en el historial. La etapa 1 no duplica su ficha.');return}const duration=meta.frames?formatDuration(meta.frames)+' aprox.':'Por analizar';items.unshift({id:`${Date.now()}-${Math.random().toString(16).slice(2,8)}`,name:file.name,size:file.size,lastModified:file.lastModified,date:new Date().toLocaleString('es-CO'),duration,version:meta.version});writeHistory(items);render();showNotice(`Archivo validado: cabecera HBR2 detectada (versión ${meta.version}). Su ficha quedó guardada en este dispositivo. La lectura completa de eventos se incorporará en una etapa posterior.`)}catch(err){showNotice(err.message||'No se pudo leer el archivo.','error')}finally{fileInput.value=''}});
matchList.addEventListener('click',e=>{const btn=e.target.closest('[data-remove]');if(!btn)return;writeHistory(readHistory().filter(x=>x.id!==btn.dataset.remove));render();showNotice('Ficha quitada del historial local. El archivo original no se ha borrado.');});
document.getElementById('clearHistory').addEventListener('click',()=>{const items=readHistory();if(!items.length){showNotice('El historial ya está vacío.');return}if(!confirm('¿Vaciar todas las fichas del historial de este dispositivo? Los archivos originales no se borrarán.'))return;writeHistory([]);render();showNotice('Historial local vaciado. Los archivos originales no se han borrado.');});
render();
// Native Android bridge: opens the system document picker and validates the HBR2 header.
const importLabel = document.querySelector('label[for="replayFile"]');
if (window.AndroidBridge && importLabel) importLabel.addEventListener('click', e => { e.preventDefault(); window.AndroidBridge.chooseReplay(); });
window.importNativeReplay = function(name,size,hex){
  try {
    if (!hex || hex.slice(0,8).toLowerCase() !== '48425232') throw new Error('La cabecera no coincide con HBR2. Selecciona una repetición .hbr2 válida.');
    const version = parseInt(hex.slice(8,10),16) || 0;
    const frames = hex.length >= 18 ? parseInt(hex.slice(10,18).match(/../g).reverse().join(''),16) : 0;
    const items=readHistory();
    if(items.some(x=>x.name===name&&x.size===size)){showNotice('Esta repetición ya está en el historial.');return;}
    items.unshift({id:`${Date.now()}-${Math.random().toString(16).slice(2,8)}`,name,size,lastModified:0,date:new Date().toLocaleString('es-CO'),duration:frames?formatDuration(frames)+' aprox.':'Por analizar',version});
    writeHistory(items);render();showNotice(`Archivo validado: cabecera HBR2 detectada (versión ${version}). Su ficha quedó guardada en este dispositivo. La lectura completa de eventos llegará en una etapa posterior.`);
  } catch(err){showNotice(err.message||'No se pudo validar el archivo.','error');}
};
window.nativeImportError = function(message){showNotice(message,'error')};
