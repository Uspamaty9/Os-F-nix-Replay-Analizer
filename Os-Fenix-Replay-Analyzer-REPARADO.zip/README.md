# Os Fênix Replay Analyzer — Etapa 1

Base inicial offline-first para Windows y Android, con interfaz adaptable y colores de Os Fênix.

## Qué funciona en esta etapa
- Interfaz en español y adaptable a pantallas pequeñas y grandes.
- Importación local de `.hbr2` desde el selector de archivos (Windows mediante Electron; Android mediante el selector del sistema).
- Validación preliminar de la firma `HBR2` y lectura de la versión/campo inicial de duración cuando está disponible.
- Historial local mediante `localStorage`; quitar fichas o vaciar el historial no borra los archivos originales.
- Sin llamadas a servidores ni analítica remota.

## Limitaciones conocidas
Esta es la etapa 1. **No analiza todavía los eventos internos de la repetición** y no calcula goles, asistencias, tiros, posesión ni mapas de calor. La duración mostrada es preliminar y depende de que la estructura del archivo corresponda al formato esperado. La aplicación guarda la ficha del archivo, no una copia completa del replay.

## Windows (generar instalador)
Requisitos de compilación: Node.js LTS y conexión a internet la primera vez para descargar Electron y el empaquetador. Después, el programa instalado funciona localmente.

```bash
cd desktop
npm install
npm run start
npm run dist:win
```

El instalador se genera en `desktop/dist/` como `Os-Fenix-Replay-Analyzer-Setup-0.1.0.exe`.

## Android (generar APK)
Abrir la carpeta `android/` con Android Studio (JDK 17 recomendado), dejar que Gradle resuelva el plugin Android si es la primera compilación y usar **Build > Build APK(s)**. El APK de depuración queda normalmente en `android/app/build/outputs/apk/debug/app-debug.apk`.

La app instalada no requiere conexión a internet para abrir la interfaz e importar repeticiones locales. La compilación inicial puede requerir descargar herramientas del SDK/Gradle.

## Estructura
- `app/`: interfaz y lógica compartida offline.
- `desktop/`: contenedor Electron y configuración de instalador Windows.
- `android/`: proyecto Android Studio con WebView local y selector de archivos nativo.

## Colores
- Oro: `#C89A3D`
- Rojo oscuro: `#7A0E1A`
- Negro: `#111111`
- Marfil: `#F7F3E8`
