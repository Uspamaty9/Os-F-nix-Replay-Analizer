const { app, BrowserWindow, Menu } = require('electron');
const path = require('node:path');
function createWindow(){
  const win = new BrowserWindow({width:1180,height:850,minWidth:360,minHeight:560,backgroundColor:'#111111',title:'Os Fênix Replay Analyzer',webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true}});
  win.loadFile(path.join(__dirname,'app','index.html'));
  Menu.setApplicationMenu(null);
}
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
