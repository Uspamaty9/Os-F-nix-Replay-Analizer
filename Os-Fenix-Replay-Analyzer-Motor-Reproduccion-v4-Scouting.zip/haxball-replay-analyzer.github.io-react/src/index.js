import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './mobile.scss';
import './home.scss';
import './theme.scss';
import './desktop-shell.scss';
import './desktop-game.scss';
import { applySettings } from './settings';
import { initMotion } from './motion';
import { installReplayBoard } from './tactics/replayBoard';
import store from './store';
import { Provider } from 'react-redux';

applySettings();
initMotion();
installReplayBoard();
// Las animaciones arrancan cuando ya cargaron fuentes e imágenes, para que todo sea fluido desde el primer segundo
(function () {
  let done = false;
  const go = () => { if (done) return; done = true; requestAnimationFrame(() => requestAnimationFrame(() => document.body.classList.add('fenix-ready'))); };
  try { Promise.all([document.fonts && document.fonts.ready, new Promise((r) => (document.readyState === 'complete' ? r() : window.addEventListener('load', r)))]).then(go); } catch (e) { go(); }
  setTimeout(go, 1200);
})();
document.addEventListener('contextmenu', (e) => { const t = e.target; if (!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'))) e.preventDefault(); });
document.addEventListener('selectstart', (e) => { const t = e.target && e.target.nodeType === 1 ? e.target : (e.target && e.target.parentElement); const ed = document.activeElement; if (ed && (ed.tagName === 'INPUT' || ed.tagName === 'TEXTAREA')) return; if (!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'))) e.preventDefault(); });
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
