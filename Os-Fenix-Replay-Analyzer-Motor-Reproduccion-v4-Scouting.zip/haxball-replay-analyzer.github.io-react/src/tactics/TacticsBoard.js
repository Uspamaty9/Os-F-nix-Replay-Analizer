// Pizarra táctica profesional para HaxBall. Módulo independiente del analizador de repeticiones:
// solo LEE el estado Redux (gameStats.matches) para ofrecer los jugadores registrados y guarda en su propia base.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useSelector } from 'react-redux';
import './tactics.scss';
import Icon from './icons';
import Library from './Library';
import Timeline from './Timeline';
import { DocPanel, PlayerPanel, MultiPanel, ShapePanel, StylePanel } from './panels';
import { TacticsController } from './controller';
import { TOOLS, ZONE_TOOLS } from './shapes';
import { newDoc, TEAM_COLORS, ZONES } from './model';
import { listDocs, saveDoc, listFolders, listRoster, saveRosterPlayer, getKv, setKv, serializeDoc } from './storage';
import { collectFromMatches, mergeRegistry, keyOf } from './players';
import { renderImage, renderScheme, renderSheet, canvasToBlob, recordAnimation, webmSupported, saveBlob, fileName, projectBlob } from './exporter';

const GROUPS = [
  ['select', 'pan'],
  ['player', 'ball'],
  ['erase'],
  ['pen', 'line', 'dline', 'arrow', 'carrow'],
  ['circle', 'square', 'rect', 'triangle', 'polygon'],
  ['press', 'defense', 'cover', 'custom'],
  ['text']
];
const TOOL = Object.fromEntries(TOOLS.map((t) => [t.id, t]));
const DRAWING = new Set(['pen', 'line', 'dline', 'arrow', 'carrow', 'circle', 'square', 'rect', 'triangle', 'polygon', ...ZONE_TOOLS]);
// Estado mostrado mientras se abre el proyecto: el árbol de la interfaz es siempre el mismo (el canvas no se recrea)
const EMPTY = {
  doc: newDoc('Cargando…'), fi: 0, tool: 'select', multi: false, snap: true, names: true, trails: false, ghost: true, newTeam: 'red',
  style: { color: '#F5C542', width: 3, opacity: 1, fill: false, dashed: false }, viewMode: 'full', zoom: 1, selPlayers: [], selShapes: [],
  canUndo: false, canRedo: false, polyActive: false, play: { state: 'stopped', speed: 1, loop: false }, progress: 0
};
const SAVE_TXT = { saved: 'Guardado', saving: 'Guardando…', dirty: 'Sin guardar', error: 'Error al guardar' };

// playerProvider (opcional): async () => entradas del registro (ver players.js). Lo aporta quien integra la pizarra con el Centro de análisis.
export default function TacticsBoard({ onClose, playerProvider }) {
  const canvasRef = useRef(null);
  const ctlRef = useRef(null);
  const [snap0, setS] = useState(null);
  const [progress, setProgress] = useState(0);
  const [confirmClear, setConfirmClear] = useState(false);
  const [saveState, setSaveState] = useState('saved');
  const [msg, setMsg] = useState('');
  const [lib, setLib] = useState(false);
  const [expOpen, setExpOpen] = useState(false);
  const [busy, setBusy] = useState(null);
  const [folders, setFolders] = useState([]);
  const [roster, setRoster] = useState([]);
  const [external, setExternal] = useState([]);
  const [panel, setPanel] = useState(false);
  const matches = useSelector((st) => (st.gameStats ? st.gameStats.matches : null));

  const pending = useRef(null), timer = useRef(0), msgTimer = useRef(0), progT = useRef(0), notesT = useRef({});
  const abortRef = useRef(null);
  const libRef = useRef(false), expRef = useRef(false), busyRef = useRef(null);
  libRef.current = lib; expRef.current = expOpen; busyRef.current = busy;

  const flash = useCallback((m) => { setMsg(m); clearTimeout(msgTimer.current); msgTimer.current = setTimeout(() => setMsg(''), 2600); }, []);

  // ---------- guardado automático ----------
  const flush = useCallback(async () => {
    clearTimeout(timer.current);
    const d = pending.current; if (!d) return;
    pending.current = null; setSaveState('saving');
    const ok = await saveDoc(d);
    if (pending.current) return; // llegaron más cambios mientras se guardaba
    setSaveState(ok ? 'saved' : 'error');
    if (ok) setKv('last', d.id);
  }, []);

  const onDocChange = useCallback((doc) => {
    pending.current = doc; setSaveState('dirty');
    clearTimeout(timer.current); timer.current = setTimeout(flush, 800);
  }, [flush]);

  const reloadMeta = useCallback(async () => { setFolders(await listFolders()); setRoster(await listRoster()); }, []);

  // ---------- arranque ----------
  useEffect(() => {
    let alive = true;
    const canvas = canvasRef.current;
    const ctl = new TacticsController(canvas, {
      onState: (snap) => { if (alive) setS(snap); },
      onDocChange,
      onToast: flash,
      onProgress: (x) => { const t = performance.now(); if (t - progT.current > 50) { progT.current = t; setProgress(x); } },
      onFocus: () => { const a = document.activeElement; if (a && a !== document.body && a.blur) a.blur(); },
      onFocusLabel: () => { setPanel(true); setTimeout(() => { const el = document.getElementById('tx-shape-label'); if (el) { el.focus(); el.select(); } }, 80); },
      onSave: () => { flush(); flash('Guardado'); }
    });
    ctlRef.current = ctl;
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => ctl.resize()) : null;
    if (ro) ro.observe(canvas.parentElement); else window.addEventListener('resize', () => ctl.resize());
    (async () => {
      await reloadMeta();
      const docs = await listDocs();
      const last = await getKv('last');
      let d = docs.find((x) => x.id === last) || docs[0];
      if (!d) { d = newDoc('Pizarra 1'); await saveDoc(d); await setKv('last', d.id); }
      if (alive) ctl.load(d);
    })();
    const hide = () => { if (document.visibilityState === 'hidden') flush(); };
    document.addEventListener('visibilitychange', hide);
    window.addEventListener('pagehide', flush);
    return () => {
      alive = false; flush();
      document.removeEventListener('visibilitychange', hide); window.removeEventListener('pagehide', flush);
      if (ro) ro.disconnect();
      ctl.destroy(); ctlRef.current = null;
      clearTimeout(msgTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- botón atrás del móvil / Esc: cierra lo último que se abrió ----------
  const requestClose = useCallback(async () => { await flush(); onClose && onClose(); }, [flush, onClose]);
  useEffect(() => {
    const prev = window.__fenixBack;
    window.__fenixBack = function () {
      const ctl = ctlRef.current;
      if (busyRef.current) { if (abortRef.current) abortRef.current.abort(); return 'ok'; }
      if (expRef.current) { setExpOpen(false); return 'ok'; }
      if (libRef.current) { setLib(false); return 'ok'; }
      if (ctl && ctl.poly) { ctl.cancelPoly(); return 'ok'; }
      requestClose();
      return 'ok';
    };
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      if (expRef.current) { setExpOpen(false); e.stopPropagation(); } else if (libRef.current) { setLib(false); e.stopPropagation(); }
    };
    window.addEventListener('keydown', onKey, true);
    return () => { window.__fenixBack = prev; window.removeEventListener('keydown', onKey, true); };
  }, [requestClose]);

  // ---------- jugadores registrados ----------
  const live = useMemo(() => collectFromMatches(matches), [matches]);
  const registry = useMemo(() => mergeRegistry(live, roster, external), [live, roster, external]);

  // Perfiles del proveedor externo (se actualizan solos cuando cambian los datos del Centro de análisis)
  useEffect(() => {
    if (!playerProvider) return undefined;
    let alive = true;
    const load = async () => { try { const list = await playerProvider(); if (alive && Array.isArray(list)) setExternal(list); } catch (e) { /* sin proveedor: se sigue con lo local */ } };
    load();
    window.addEventListener('fenix-scouting-changed', load);
    return () => { alive = false; window.removeEventListener('fenix-scouting-changed', load); };
  }, [playerProvider]);

  // El plantel guarda a los jugadores vistos en el analizador para que sigan disponibles después
  useEffect(() => {
    const list = Object.values(live); if (!list.length) return undefined;
    const t = setTimeout(async () => {
      let changed = false;
      for (const e of list) {
        const prev = roster.find((r) => (r.key || keyOf(r.nick)) === e.key);
        if (prev && JSON.stringify(prev.stats) === JSON.stringify(e.stats) && prev.team === e.team) continue;
        await saveRosterPlayer({ id: prev && prev.id, key: e.key, nick: e.nick, nation: e.nation, team: e.team, stats: e.stats, position: (prev && prev.position) || '', info: (prev && prev.info) || '' });
        changed = true;
      }
      if (changed) setRoster(await listRoster());
    }, 600);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [live]);

  const addRegistered = (r) => {
    const ctl = ctlRef.current; if (!ctl) return;
    ctl.addPlayerCenter({ nick: r.nick, regKey: r.key, team: r.team || 'neutral', color: TEAM_COLORS[r.team || 'neutral'] });
    setPanel(true);
  };
  const saveToRoster = async (p) => {
    const key = keyOf(p.nick); if (!key) return;
    await saveRosterPlayer({ key, nick: p.nick, team: p.team, nation: '' });
    setRoster(await listRoster());
    ctlRef.current.updatePlayer(p.id, { regKey: key });
    flash('«' + p.nick + '» guardado en el plantel');
  };
  const saveNotes = (reg, info) => {
    clearTimeout(notesT.current[reg.key]);
    notesT.current[reg.key] = setTimeout(async () => {
      await saveRosterPlayer({ id: reg.id, key: reg.key, nick: reg.nick, nation: reg.nation, team: reg.team, stats: reg.external ? null : reg.stats, position: reg.position || '', info });
      setRoster(await listRoster());
    }, 600);
  };

  // ---------- biblioteca ----------
  const openDoc = async (d) => { await flush(); ctlRef.current.load(d); setLib(false); pending.current = null; setSaveState('saved'); await setKv('last', d.id); };
  const newBoard = async (folderId) => {
    await flush();
    const docs = await listDocs();
    const d = newDoc('Pizarra ' + (docs.length + 1)); d.folderId = folderId || null;
    await saveDoc(d); await setKv('last', d.id);
    ctlRef.current.load(d); setLib(false); pending.current = null; setSaveState('saved'); flash('Pizarra nueva');
  };
  const libChanged = async (deletedId) => {
    await reloadMeta();
    if (deletedId && ctlRef.current && ctlRef.current.doc.id === deletedId) { // se borró la pizarra abierta
      const docs = await listDocs();
      const d = docs[0] || newDoc('Pizarra 1'); if (!docs.length) await saveDoc(d);
      ctlRef.current.load(d); await setKv('last', d.id);
    }
  };

  // ---------- exportación ----------
  const doExport = async (kind) => {
    setExpOpen(false);
    const ctl = ctlRef.current; if (!ctl) return;
    ctl.stop();
    const doc = ctl.doc;
    try {
      if (kind === 'json') { const n = fileName(doc, '', 'json'); await saveBlob(projectBlob(doc), n, 'application/json'); flash('Proyecto exportado: ' + n); return; }
      if (kind === 'png') { const n = fileName(doc, 'paso-' + (ctl.fi + 1), 'png'); await saveBlob(await canvasToBlob(renderImage(doc, ctl.fi, { trails: ctl.trails, names: ctl.names })), n, 'image/png'); flash('Imagen guardada: ' + n); return; }
      if (kind === 'scheme') { const n = fileName(doc, 'esquema', 'png'); await saveBlob(await canvasToBlob(renderScheme(doc)), n, 'image/png'); flash('Esquema guardado: ' + n); return; }
      if (kind === 'sheet') { const n = fileName(doc, 'secuencia', 'png'); await saveBlob(await canvasToBlob(renderSheet(doc)), n, 'image/png'); flash('Secuencia guardada: ' + n); return; }
      if (kind === 'video') {
        if (doc.frames.length < 2) { flash('Añade al menos 2 pasos para exportar la animación'); return; }
        if (!webmSupported()) { flash('Este dispositivo no graba vídeo: se exporta la secuencia como imagen'); await doExport('sheet'); return; }
        const ac = new AbortController(); abortRef.current = ac; setBusy({ label: 'Grabando animación…', pct: 0 });
        const blob = await recordAnimation(doc, { speed: ctl.play.speed, signal: ac.signal, onProgress: (p) => setBusy({ label: 'Grabando animación…', pct: p }) });
        setBusy(null); abortRef.current = null;
        if (ac.signal.aborted) { flash('Exportación cancelada'); return; }
        const n = fileName(doc, 'animacion', 'webm'); await saveBlob(blob, n, 'video/webm'); flash('Animación guardada: ' + n);
      }
    } catch (e) { setBusy(null); flash('No se pudo exportar: ' + (e && e.message ? e.message : 'error')); }
  };

  const s = snap0 || EMPTY;
  const ctl = ctlRef.current;

  // En pantallas estrechas el panel se abre al tocar una ficha o figura existente (no al colocar fichas nuevas)
  const selSig = s.selPlayers.join(',') + '|' + s.selShapes.join(',');
  useEffect(() => { if (s.tool === 'select' && (s.selPlayers.length || s.selShapes.length)) setPanel(true); }, [selSig]); // eslint-disable-line react-hooks/exhaustive-deps
  const nShapes = s.selShapes.length, nPl = s.selPlayers.filter((i) => i !== 'ball').length, ballSel = s.selPlayers.includes('ball');
  const tool = TOOL[s.tool];
  let body, title;
  if (nShapes) { body = <ShapePanel ctl={ctl} s={s} />; title = 'Figura'; } else if (nPl >= 2) { body = <MultiPanel ctl={ctl} s={s} />; title = 'Selección'; } else if (nPl === 1) { body = <PlayerPanel ctl={ctl} s={s} registry={registry} onSaveRoster={saveToRoster} onNotes={saveNotes} />; title = 'Jugador'; } else if (ballSel) {
    body = (<section className='tx-sec'><h4>Balón</h4><button type='button' className='tx-btn danger' onClick={() => ctl.removeBall()}><Icon name='trash' size={16} /><span>Quitar balón</span></button></section>); title = 'Balón';
  } else if (DRAWING.has(s.tool)) {
    const z = ZONE_TOOLS.includes(s.tool);
    body = <StylePanel ctl={ctl} s={s} st={s.style} title={tool.label} fillable={['circle', 'square', 'rect', 'triangle', 'polygon'].includes(s.tool)} zoneKind={z} />; title = 'Dibujo';
  } else { body = <DocPanel ctl={ctl} s={s} folders={folders} registry={registry} onAddRegistered={addRegistered} />; title = 'Pizarra'; }

  const dis = s.play.state !== 'stopped';
  const views = [['full', 'full', 'Cancha completa'], ['left', 'halfl', 'Media cancha izquierda'], ['right', 'halfr', 'Media cancha derecha']];
  const viewControls = (
    <>
      <div className='tx-seg' role='group' aria-label='Vista del campo'>
        {views.map(([m, ic, t]) => <button type='button' key={m} className={s.viewMode === m ? 'on' : ''} onClick={() => ctl.setViewMode(m)} title={t} aria-label={t} aria-pressed={s.viewMode === m}><Icon name={ic} /></button>)}
      </div>
      <button type='button' className='tx-icon' onClick={() => ctl.fit()} title='Ajustar al espacio (0)' aria-label='Ajustar'><Icon name='fit' /></button>
    </>
  );

  const tree = (
    <div className={'tx-root' + (panel ? ' panel-open' : '')} data-ready={snap0 ? '1' : '0'} role='application' aria-label='Pizarra táctica'>
      <header className='tx-top'>
        <button type='button' className='tx-icon' onClick={requestClose} title='Volver al inicio' aria-label='Volver'><Icon name='back' /></button>
        <div className='tx-title'>
          <b title={s.doc.name}>{s.doc.name}</b>
          <small className={'tx-save ' + saveState}>{SAVE_TXT[saveState]}</small>
        </div>
        <div className='tx-top-actions'>
          <button type='button' className='tx-icon' onClick={() => ctl.undo()} disabled={!s.canUndo} title='Deshacer (Ctrl+Z)' aria-label='Deshacer'><Icon name='undo' /></button>
          <button type='button' className='tx-icon' onClick={() => ctl.redo()} disabled={!s.canRedo} title='Rehacer (Ctrl+Y)' aria-label='Rehacer'><Icon name='redo' /></button>
          <span className='tx-sep hide-sm' />
          <div className='tx-viewctl hide-sm'>{viewControls}</div>
          <button type='button' className='tx-icon hide-sm' onClick={() => ctl.zoomBy(1 / 1.25)} title='Alejar (−)' aria-label='Alejar'><Icon name='zoomout' /></button>
          <button type='button' className='tx-icon hide-sm' onClick={() => ctl.zoomBy(1.25)} title='Acercar (+)' aria-label='Acercar'><Icon name='zoomin' /></button>
          <span className='tx-sep hide-sm' />
          <button type='button' className='tx-icon' onClick={() => { flush(); setLib(true); }} title='Biblioteca' aria-label='Biblioteca'><Icon name='library' /></button>
          <div className='tx-menu-wrap'>
            <button type='button' className={'tx-icon' + (expOpen ? ' on' : '')} onClick={() => setExpOpen(!expOpen)} title='Exportar' aria-label='Exportar' aria-expanded={expOpen}><Icon name='download' /></button>
            {expOpen && (
              <>
                <div className='tx-menu-back' onClick={() => setExpOpen(false)} />
                <div className='tx-menu' role='menu'>
                  <button type='button' role='menuitem' onClick={() => doExport('png')}><Icon name='image' size={18} /><span>Imagen del paso actual<small>PNG</small></span></button>
                  <button type='button' role='menuitem' onClick={() => doExport('scheme')}><Icon name='trail' size={18} /><span>Esquema táctico<small>PNG con trayectorias</small></span></button>
                  <button type='button' role='menuitem' onClick={() => doExport('sheet')}><Icon name='film' size={18} /><span>Secuencia por pasos<small>PNG con todos los pasos</small></span></button>
                  <button type='button' role='menuitem' onClick={() => doExport('video')}><Icon name='play' size={18} /><span>Animación<small>{webmSupported() ? 'Vídeo WebM' : 'No disponible aquí'}</small></span></button>
                  <button type='button' role='menuitem' onClick={() => doExport('json')}><Icon name='save' size={18} /><span>Jugada individual<small>Archivo de proyecto (.json)</small></span></button>
                </div>
              </>
            )}
          </div>
          <button type='button' className={'tx-icon show-sm' + (panel ? ' on' : '')} onClick={() => setPanel(!panel)} title='Panel' aria-label='Panel'><Icon name='panel' /></button>
        </div>
      </header>

      <div className='tx-body'>
        <nav className='tx-tools' aria-label='Herramientas'>
          {GROUPS.map((g, gi) => (
            <div className='tx-group' key={gi}>
              {g.map((id) => (
                <button type='button' key={id} className={'tx-tool' + (s.tool === id ? ' on' : '')} onClick={() => ctl.setTool(id)} title={TOOL[id].label + ' — ' + TOOL[id].hint} aria-label={TOOL[id].label} aria-pressed={s.tool === id}>
                  <Icon name={id} size={21} />
                </button>
              ))}
              {g[0] === 'player' && (
                <>
                  <button type='button' className={'tx-tool team red' + (s.tool === 'player' && s.newTeam === 'red' ? ' on' : '')} onClick={() => { ctl.setNewTeam('red'); ctl.setTool('player'); }} title='Colocar fichas del equipo ROJO' aria-label='Ficha equipo rojo' aria-pressed={s.tool === 'player' && s.newTeam === 'red'}><i /></button>
                  <button type='button' className={'tx-tool team blue' + (s.tool === 'player' && s.newTeam === 'blue' ? ' on' : '')} onClick={() => { ctl.setNewTeam('blue'); ctl.setTool('player'); }} title='Colocar fichas del equipo AZUL' aria-label='Ficha equipo azul' aria-pressed={s.tool === 'player' && s.newTeam === 'blue'}><i /></button>
                </>
              )}
              {gi === 0 && (
                <button type='button' className={'tx-tool' + (s.multi ? ' on' : '')} onClick={() => ctl.setFlag('multi', !s.multi)} title='Selección múltiple: toca varias fichas para elegirlas' aria-label='Selección múltiple' aria-pressed={s.multi}><Icon name='multi' size={21} /></button>
              )}
            </div>
          ))}
        </nav>

        <main className='tx-stage'>
          <canvas ref={canvasRef} className='tx-canvas' aria-label='Campo de HaxBall' />
          <div className='tx-viewbar show-sm'>{viewControls}</div>
          {!s.polyActive && !dis && (
            <div className='tx-actbar'>
              <button type='button' className={'tx-act' + (s.tool === 'erase' ? ' on' : '')} onClick={() => ctl.setTool(s.tool === 'erase' ? 'select' : 'erase')} aria-pressed={s.tool === 'erase'} aria-label='Borrador'><Icon name='erase' size={20} /><span>Borrador</span></button>
              <button type='button' className='tx-act' disabled={!(s.selPlayers.length + s.selShapes.length)} onClick={() => ctl.deleteSelection()} aria-label='Borrar selección'><Icon name='trash' size={20} /><span>Borrar</span></button>
              <button type='button' className={'tx-act danger' + (confirmClear ? ' on' : '')} onClick={() => { if (confirmClear) { ctl.clearBoard(); setConfirmClear(false); } else { setConfirmClear(true); setTimeout(() => setConfirmClear(false), 3500); } }} aria-label='Limpiar todo'><Icon name='close' size={20} /><span>{confirmClear ? '¿Seguro?' : 'Limpiar todo'}</span></button>
            </div>
          )}
          <div className='tx-hintbar' aria-live='polite'>
            <b>{tool ? tool.label : ''}</b>
            <span>{dis ? 'Animación en curso: pausa para editar' : s.multi && s.tool === 'select' ? 'Selección múltiple activa: toca varias fichas' : tool ? tool.hint : ''}</span>
          </div>
          {s.polyActive && (
            <div className='tx-polybar'>
              <button type='button' className='tx-btn primary' onClick={() => ctl.finishPoly()}><Icon name='check' size={16} /><span>Cerrar figura</span></button>
              <button type='button' className='tx-btn' onClick={() => ctl.undoPolyPoint()}><Icon name='undo' size={16} /><span>Quitar punto</span></button>
              <button type='button' className='tx-btn' onClick={() => ctl.cancelPoly()}><Icon name='close' size={16} /><span>Cancelar</span></button>
            </div>
          )}
          {nPl >= 2 && !s.polyActive && !dis && (
            <div className='tx-quick'>
              <button type='button' className='tx-btn primary' onClick={() => ctl.linkSelection(nPl === 4 ? 'quad' : undefined)}>
                <Icon name='link' size={16} /><span>{nPl === 2 ? 'Crear conexión' : nPl === 3 ? 'Crear triángulo' : nPl === 4 ? 'Crear estructura' : 'Crear polígono'}</span>
              </button>
              {nPl === 4 && <button type='button' className='tx-btn' onClick={() => ctl.linkSelection('square')}><Icon name='square' size={16} /><span>Cuadrado</span></button>}
            </div>
          )}
          {dis && <div className='tx-playing'>{s.play.state === 'playing' ? 'Reproduciendo' : 'En pausa'} · paso {Math.min(s.doc.frames.length, Math.floor(s.play.state === 'playing' ? progress : s.progress) + 1)} de {s.doc.frames.length}</div>}
        </main>

        <aside className='tx-panel' aria-label={'Panel: ' + title}>
          <div className='tx-panel-head'>
            <h3>{title}</h3>
            <button type='button' className='tx-icon show-sm' onClick={() => setPanel(false)} aria-label='Cerrar panel'><Icon name='close' /></button>
          </div>
          <div className='tx-panel-body'>{body}</div>
        </aside>
      </div>

      <Timeline ctl={ctl} s={s} progress={progress} />

      {lib && <Library currentId={s.doc.id} onOpen={openDoc} onNew={newBoard} onClose={() => setLib(false)} onChanged={libChanged} toast={flash} />}
      {busy && (
        <div className='tx-overlay'>
          <div className='tx-sheet tx-busy' role='alertdialog' aria-label={busy.label}>
            <h3>{busy.label}</h3>
            <div className='tx-bar'><i style={{ width: Math.round(busy.pct * 100) + '%' }} /></div>
            <button type='button' className='tx-btn' onClick={() => abortRef.current && abortRef.current.abort()}>Cancelar</button>
          </div>
        </div>
      )}
      {msg && <div className='tx-toast' role='status'>{msg}</div>}
    </div>
  );
  // En un portal sobre <body>, como las demás hojas de la app: no depende de la posición del inicio
  return typeof document !== 'undefined' && document.body ? createPortal(tree, document.body) : tree;
}

export { serializeDoc, ZONES };
