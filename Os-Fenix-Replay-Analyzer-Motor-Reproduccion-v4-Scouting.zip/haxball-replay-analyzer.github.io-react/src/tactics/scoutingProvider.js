// Puente OPCIONAL entre la pizarra táctica y el Centro de análisis (src/scouting).
// Solo LEE: los perfiles, estadísticas y calificaciones salen de la misma base y las mismas funciones que el Centro de análisis,
// así las cifras coinciden en toda la app. No inventa datos: sin partidos suficientes no hay calificación.
//
// Se copia a src/tactics/scoutingProvider.js SOLO cuando existe src/scouting (ver integrate.py --with-scouting).
import { loadAll, getKv } from '../scouting/db';
import { buildModel, playerProfile, ratingAverage, teamName, ownTeamId, EMPTY_FILTERS } from '../scouting/model';
import { normNick } from '../scouting/ingest';

const pct = (v) => (v == null ? null : Math.round(v * 100) + '%');

export async function scoutingPlayers() {
  const store = await loadAll();
  if (!store.players || !store.players.length) return [];
  const model = buildModel(store);
  const own = ownTeamId(model);
  return model.players.map((p) => {
    const prof = playerProfile(model, p.id, EMPTY_FILTERS);
    const a = prof.agg;
    const rt = ratingAverage(model, p.id, null);
    const sources = prof.history.map((h) => (h.rating && h.rating.final.values.overall != null ? h.rating.final.sources.overall : null)).filter(Boolean);
    const stats = [
      { id: 'matches', label: 'Partidos', value: a.matches, prov: 'C' },
      { id: 'goals', label: 'Goles', value: a.goals, prov: 'E' },
      { id: 'assists', label: 'Asistencias', value: a.assists, prov: 'E' },
      { id: 'kicks', label: 'Toques', value: a.kicks, prov: 'E' },
      { id: 'shotsOT', label: 'Tiros a puerta', value: a.shotsOT, prov: 'E' },
      { id: 'passesCompleted', label: 'Pases completados', value: a.passesCompleted, prov: 'C' },
      { id: 'passAccuracy', label: 'Precisión de pases', value: pct(a.passAccuracy), prov: 'C' },
      { id: 'recoveries', label: 'Recuperaciones', value: a.recoveries, prov: 'C' },
      { id: 'interceptions', label: 'Intercepciones', value: a.interceptions, prov: 'C' },
      { id: 'keyPasses', label: 'Pases clave', value: a.keyPasses, prov: 'C' },
    ];
    return {
      key: normNick(p.nick), nick: p.nick, aliases: p.aliases || [], nation: '', team: null,
      teamName: teamName(model, p.teamId, ''), position: p.position || '', info: p.notes || '', avatar: p.avatar || null, mine: !!own && p.teamId === own,
      stats, rating: rt ? { value: Math.round(rt.avg * 10) / 10, n: rt.n, prov: sources.length && sources.every((s) => s === 'manual') ? 'M' : 'C' } : null,
    };
  });
}

// Canchas de los partidos importados (geometría guardada al analizar cada repetición)
export async function scoutingStadiums() {
  const m = (await getKv('stadiums', {})) || {};
  return Object.values(m).filter((g) => g && g.name && g.halfW);
}
