# Os Fênix Replay Analyzer — adaptación móvil (código fuente)

Esta versión parte del código fuente original de HaxBall Replay Analyzer y conserva el motor de lectura/reproducción en `src/game2.js` y los componentes de estadísticas en `src/components/`.

## Cambios incluidos
- Estilos adaptables para teléfonos en `src/App.scss` (controles táctiles, listas desplazables, tablas con desplazamiento horizontal y espacio seguro de pantalla).
- Marca de Os Fênix en el título.
- Página HTML simplificada para reducir dependencias externas de fuentes, analítica y anuncios.
- El archivo `.hbr2` seleccionado se procesa localmente: se quitó el envío automático del archivo y de sus estadísticas al servidor desde el flujo de carga local.

## Ejecutar / compilar
Requiere Node.js y npm. En la carpeta del proyecto:

```bash
npm ci
npm start
```

Para generar el sitio compilado:

```bash
npm run build
```

## Importante
Este archivo es el **código fuente**, no un APK firmado. El entorno usado para esta edición no consiguió instalar todas las dependencias (`react-scripts` no quedó disponible), por lo que no se pudo generar ni probar un build de producción o un APK. Para Android, hay que compilar el build y empaquetarlo en el proyecto Android; para actualizar una app ya instalada conservando datos, también se necesita la misma clave de firma privada que se usó en la versión instalada.
