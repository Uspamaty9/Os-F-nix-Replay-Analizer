import React from "react";

function Header() {
  return (
    <div className="header">
      <span className="title">OS FÊNIX · REPLAY ANALYZER</span>
      <span className="header-subtitle">HaxBall · Reproducción y análisis local</span>
    </div>
  );
}

export default Header;
