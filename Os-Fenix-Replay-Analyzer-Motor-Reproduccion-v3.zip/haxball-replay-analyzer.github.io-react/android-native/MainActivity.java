package com.osfenix.replayanalyzer.motor;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(HbrScanner.class);
        super.onCreate(savedInstanceState);
    }
}
