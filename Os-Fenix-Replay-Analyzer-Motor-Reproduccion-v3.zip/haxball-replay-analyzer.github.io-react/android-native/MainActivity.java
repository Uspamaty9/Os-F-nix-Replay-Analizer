package com.osfenix.replayanalyzer.motor;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.OrientationEventListener;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(HbrScanner.class);
        super.onCreate(savedInstanceState);
        // Gira segun el giro automatico del celular (si esta desactivado, se queda como esta)
        try { setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER); } catch (Exception e) { }
        setupRotationGuard();
        setupFullScreen();
        setupBack();
    }

    // Giro automatico del celular, pero nunca boca abajo (camara hacia abajo): ahi se queda en vertical normal
    private boolean autoMode = true;
    private boolean blocked180 = false;
    private OrientationEventListener oel;

    private boolean autoRotateOn() {
        try { return Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0) == 1; } catch (Exception e) { return false; }
    }

    private void setupRotationGuard() {
        try {
            oel = new OrientationEventListener(this) {
                @Override
                public void onOrientationChanged(int a) {
                    if (a == OrientationEventListener.ORIENTATION_UNKNOWN || !autoMode) return;
                    try {
                        if (!blocked180 && a >= 160 && a <= 200 && autoRotateOn()) {
                            blocked180 = true;
                            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                        } else if (blocked180 && (a < 140 || a > 220)) {
                            blocked180 = false;
                            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER);
                        }
                    } catch (Exception e) { }
                }
            };
            if (oel.canDetectOrientation()) oel.enable();
        } catch (Exception e) { }
    }

    @Override
    public void onDestroy() {
        try { if (oel != null) oel.disable(); } catch (Exception e) { }
        super.onDestroy();
    }

    // Boton atras: lo atiende la web (cierra paneles o pregunta si salir)
    private void setupBack() {
        try {
            final WebView wv = getBridge().getWebView();
            wv.addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void exit() {
                    runOnUiThread(() -> finish());
                }
                @JavascriptInterface
                public void lockOrientation(final String mode) {
                    runOnUiThread(() -> {
                        try {
                            int o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER;
                            autoMode = true; blocked180 = false;
                            if ("portrait".equals(mode)) { o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT; autoMode = false; }
                            else if ("landscape".equals(mode)) { o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; autoMode = false; }
                            setRequestedOrientation(o);
                        } catch (Exception e) { }
                    });
                }
                @JavascriptInterface
                public void lightBars(final boolean light) {
                    runOnUiThread(() -> {
                        try {
                            Window w = getWindow();
                            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                            c.setAppearanceLightStatusBars(light);
                            c.setAppearanceLightNavigationBars(light);
                        } catch (Exception e) { }
                    });
                }
            }, "FenixNative");
        } catch (Exception e) { }
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    final WebView wv = getBridge().getWebView();
                    wv.evaluateJavascript("(function(){try{return window.__fenixBack?window.__fenixBack():'no'}catch(e){return 'no'}})()", value -> {
                        if (value == null || !value.contains("ok")) moveTaskToBack(true);
                    });
                } catch (Exception e) {
                    moveTaskToBack(true);
                }
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    public void onResume() {
        super.onResume();
        hideBars();
    }

    private boolean isLandscape() {
        return getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
    }

    // Vertical: barra de estado y de botones visibles. Horizontal: pantalla completa (se muestran deslizando desde el borde).
    private void setupFullScreen() {
        Window w = getWindow();
        w.getDecorView().setBackgroundColor(Color.parseColor("#111111"));
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        // Avisar a la web de los margenes del recorte (camara) solo en horizontal
        ViewCompat.setOnApplyWindowInsetsListener(w.getDecorView(), (v, insets) -> {
            try {
                Insets c = isLandscape()
                        ? insets.getInsets(WindowInsetsCompat.Type.displayCutout())
                        : insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
                if (!isLandscape()) c = Insets.of(0, c.top, 0, c.bottom);
                float d = getResources().getDisplayMetrics().density;
                final String js = "var s=document.documentElement.style;s.setProperty('--sal','" + Math.round(c.left / d)
                        + "px');s.setProperty('--sar','" + Math.round(c.right / d) + "px');s.setProperty('--sat','" + Math.round(c.top / d)
                        + "px');s.setProperty('--sab','" + Math.round(c.bottom / d) + "px');";
                if (getBridge() != null && getBridge().getWebView() != null) {
                    final WebView wv = getBridge().getWebView();
                    wv.post(() -> wv.evaluateJavascript(js, null));
                }
            } catch (Exception e) { }
            return insets;
        });
        hideBars();
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        hideBars();
        try { ViewCompat.requestApplyInsets(getWindow().getDecorView()); } catch (Exception e) { }
    }

    private void hideBars() {
        try {
            Window w = getWindow();
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
            if (isLandscape()) {
                WindowCompat.setDecorFitsSystemWindows(w, false);
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            } else {
                WindowCompat.setDecorFitsSystemWindows(w, false);
                c.show(WindowInsetsCompat.Type.systemBars());
            }
        } catch (Exception e) { }
    }
}
