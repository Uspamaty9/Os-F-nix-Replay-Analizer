import sys, os
from PIL import Image
src, res = sys.argv[1], sys.argv[2]
im = Image.open(src).convert('RGB')
for d, px in (('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)):
    p = os.path.join(res, 'mipmap-' + d)
    os.makedirs(p, exist_ok=True)
    o = im.resize((px, px), Image.LANCZOS)
    for n in ('ic_launcher.png','ic_launcher_round.png','ic_launcher_foreground.png'):
        o.save(os.path.join(p, n))
print('ok')
