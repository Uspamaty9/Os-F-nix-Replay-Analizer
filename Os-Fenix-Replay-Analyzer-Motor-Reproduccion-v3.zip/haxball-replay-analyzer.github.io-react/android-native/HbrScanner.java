package com.osfenix.replayanalyzer.motor;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

@CapacitorPlugin(name = "HbrScanner")
public class HbrScanner extends Plugin {

    @PluginMethod
    public void pick(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                    Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
        } catch (Exception ignored) { }
        startActivityForResult(call, i, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("cancel");
            return;
        }
        final Uri uri = result.getData().getData();
        final PluginCall c = call;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String name = "repeticion.hbr2";
                    Cursor cur = getContext().getContentResolver().query(uri, null, null, null, null);
                    if (cur != null) {
                        try {
                            int idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (idx >= 0 && cur.moveToFirst()) name = cur.getString(idx);
                        } finally { cur.close(); }
                    }
                    InputStream in = getContext().getContentResolver().openInputStream(uri);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    JSObject o = new JSObject();
                    o.put("name", name);
                    o.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                    c.resolve(o);
                } catch (Exception e) {
                    c.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }
}
