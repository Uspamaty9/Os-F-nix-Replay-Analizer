package com.osfenix.replayanalyzer.motor;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.InputStream;

@CapacitorPlugin(name = "HbrScanner")
public class HbrScanner extends Plugin {

    @PluginMethod
    public void pick(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream"});
        try {
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                    Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
        } catch (Exception ignored) { }
        startActivityForResult(call, i, "pickResult");
    }

    private boolean granted() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void hasAccess(PluginCall call) {
        JSObject o = new JSObject();
        o.put("granted", granted());
        o.put("api", Build.VERSION.SDK_INT);
        call.resolve(o);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Exception e) {
                try {
                    Intent i2 = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i2);
                } catch (Exception ignored) { }
            }
        }
        call.resolve();
    }

    private void scan(File dir, int depth, List<File> out) {
        if (depth > 7 || out.size() > 2000) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            String n = f.getName();
            if (f.isDirectory()) {
                if (n.startsWith(".") || n.equals("Android")) continue;
                scan(f, depth + 1, out);
            } else if (n.toLowerCase().endsWith(".hbr2")) {
                out.add(f);
            }
        }
    }

    @PluginMethod
    public void list(final PluginCall call) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    List<File> found = new ArrayList<File>();
                    scan(Environment.getExternalStorageDirectory(), 0, found);
                    Collections.sort(found, new Comparator<File>() {
                        @Override
                        public int compare(File a, File b) {
                            return Long.compare(b.lastModified(), a.lastModified());
                        }
                    });
                    JSArray arr = new JSArray();
                    for (int k = 0; k < found.size() && k < 300; k++) {
                        File f = found.get(k);
                        JSObject o = new JSObject();
                        o.put("path", f.getAbsolutePath());
                        o.put("name", f.getName());
                        o.put("size", f.length());
                        o.put("modified", f.lastModified());
                        arr.put(o);
                    }
                    JSObject r = new JSObject();
                    r.put("files", arr);
                    call.resolve(r);
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    @PluginMethod
    public void readFile(final PluginCall call) {
        final String path = call.getString("path");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (path == null || !path.toLowerCase().endsWith(".hbr2")) { call.reject("archivo no valido"); return; }
                    File f = new File(path);
                    FileInputStream in = new FileInputStream(f);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    JSObject o = new JSObject();
                    o.put("name", f.getName());
                    o.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                    call.resolve(o);
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("cancel");
            return;
        }
        final Uri uri = result.getData().getData();
        final PluginCall c = call;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String name = "repeticion.hbr2";
                    Cursor cur = getContext().getContentResolver().query(uri, null, null, null, null);
                    if (cur != null) {
                        try {
                            int idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (idx >= 0 && cur.moveToFirst()) name = cur.getString(idx);
                        } finally { cur.close(); }
                    }
                    InputStream in = getContext().getContentResolver().openInputStream(uri);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    JSObject o = new JSObject();
                    o.put("name", name);
                    o.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                    c.resolve(o);
                } catch (Exception e) {
                    c.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }
}
