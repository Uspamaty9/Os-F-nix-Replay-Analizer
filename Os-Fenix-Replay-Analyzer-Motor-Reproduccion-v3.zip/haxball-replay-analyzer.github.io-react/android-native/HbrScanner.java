package com.osfenix.replayanalyzer.motor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;

import androidx.core.app.ActivityCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@CapacitorPlugin(name = "HbrScanner")
public class HbrScanner extends Plugin {

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return getContext().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void walk(File dir, int depth, List<File> out) {
        if (depth > 7 || out.size() > 500) return;
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            String n = f.getName();
            if (f.isDirectory()) {
                if (n.startsWith(".") || n.equals("Android")) continue;
                walk(f, depth + 1, out);
            } else if (n.toLowerCase().endsWith(".hbr2")) {
                out.add(f);
            }
        }
    }

    @PluginMethod
    public void scan(final PluginCall call) {
        final JSObject res = new JSObject();
        if (!hasAccess()) {
            res.put("needPermission", true);
            res.put("files", new JSArray());
            call.resolve(res);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    List<File> found = new ArrayList<>();
                    walk(Environment.getExternalStorageDirectory(), 0, found);
                    Collections.sort(found, new Comparator<File>() {
                        @Override
                        public int compare(File a, File b) {
                            return Long.compare(b.lastModified(), a.lastModified());
                        }
                    });
                    JSArray arr = new JSArray();
                    for (File f : found) {
                        JSObject o = new JSObject();
                        o.put("name", f.getName());
                        o.put("path", f.getAbsolutePath());
                        o.put("folder", f.getParentFile() != null ? f.getParentFile().getName() : "");
                        o.put("size", f.length());
                        o.put("modified", f.lastModified());
                        arr.put(o);
                    }
                    res.put("needPermission", false);
                    res.put("files", arr);
                    call.resolve(res);
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                getActivity().startActivity(i);
            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7);
            }
            call.resolve();
        } catch (Exception e) {
            try {
                getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                call.resolve();
            } catch (Exception e2) {
                call.reject(String.valueOf(e2.getMessage()));
            }
        }
    }

    @PluginMethod
    public void read(final PluginCall call) {
        final String path = call.getString("path");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File f = new File(path);
                    if (!f.getName().toLowerCase().endsWith(".hbr2") || f.length() > 60L * 1024 * 1024) {
                        call.reject("Archivo no válido");
                        return;
                    }
                    FileInputStream in = new FileInputStream(f);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream((int) f.length());
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    JSObject o = new JSObject();
                    o.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                    call.resolve(o);
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }
}
