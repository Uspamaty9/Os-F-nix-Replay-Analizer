import './App.scss';
import Home from './components/Home';
import React, { useEffect, useState } from 'react';
import $ from 'jquery'
import Modal from './components/Modal';

function Splash() {
  const [phase, setPhase] = useState('in');
  useEffect(() => {
    const a = setTimeout(() => setPhase('out'), 2000);
    const b = setTimeout(() => setPhase('gone'), 2650);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []);
  if (phase === 'gone') return null;
  return (
    <div className={'fenix-splash' + (phase === 'out' ? ' out' : '')} aria-hidden='true'>
      <div className='fs-rays' />
      <div className='fs-crest'>
        <img src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt='' />
        <span className='fs-shine' />
      </div>
      <div className='fs-word'>Os Fênix</div>
      <div className='fs-bar'><i /></div>
    </div>
  );
}

function App() {

  useEffect(() => {
    $('#mainDiv').fadeIn(700)
  }, [])

  return (
    <>
    <Splash />
    <div id='mainDiv' className="container flexCol" style={{ display: 'none' }}>
      <div className="flexRow flexGrow">
        <Home />
        <Modal />
      </div>
    </div>
    </>
  );
}

export default App;
