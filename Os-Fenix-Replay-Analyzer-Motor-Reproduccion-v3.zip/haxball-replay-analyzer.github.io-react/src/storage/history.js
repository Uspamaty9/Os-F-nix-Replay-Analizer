// Historial local de repeticiones (IndexedDB): funciona sin internet y sobrevive al cierre de la app.
const DB_NAME = 'os-fenix-replays';
const META = 'meta';
const DATA = 'data';

function openDb() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) { reject(new Error('IndexedDB no disponible')); return; }
    const req = window.indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(META)) db.createObjectStore(META, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(DATA)) db.createObjectStore(DATA, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function wrap(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function done(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function listReplays() {
  try {
    const db = await openDb();
    const all = await wrap(db.transaction(META).objectStore(META).getAll());
    db.close();
    return all.sort((a, b) => b.addedAt - a.addedAt);
  } catch (e) {
    return [];
  }
}

// Guarda el archivo original (sin modificarlo). Si ya existe el mismo archivo, solo lo sube al inicio.
export async function saveReplayFile(file) {
  const buffer = await file.arrayBuffer();
  const signature = [file.name, file.size, file.lastModified].join('|');
  const db = await openDb();
  const existing = await wrap(db.transaction(META).objectStore(META).getAll());
  const same = existing.find((m) => m.signature === signature);
  const tx = db.transaction([META, DATA], 'readwrite');
  let savedId = null;
  if (same) {
    same.addedAt = Date.now();
    same.hidden = false;
    tx.objectStore(META).put(same);
    savedId = same.id;
  } else {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    tx.objectStore(META).put({
      id,
      name: file.name.replace(/\.hbr2$/i, ''),
      fileName: file.name,
      size: file.size,
      signature,
      addedAt: Date.now(),
    });
    tx.objectStore(DATA).put({ id, data: buffer });
    savedId = id;
  }
  await done(tx);
  db.close();
  return savedId;
}

export async function getReplayData(id) {
  const db = await openDb();
  const rec = await wrap(db.transaction(DATA).objectStore(DATA).get(id));
  db.close();
  return rec ? rec.data : null;
}

export async function renameReplay(id, name) {
  const db = await openDb();
  const store = db.transaction(META, 'readwrite').objectStore(META);
  const meta = await wrap(store.get(id));
  if (meta) {
    meta.name = name.trim() || meta.fileName.replace(/\.hbr2$/i, '');
    await wrap(store.put(meta));
  }
  db.close();
}

export async function deleteReplay(id) {
  const db = await openDb();
  const tx = db.transaction([META, DATA], 'readwrite');
  tx.objectStore(META).delete(id);
  tx.objectStore(DATA).delete(id);
  await done(tx);
  db.close();
}

export async function setFavorite(id, value) {
  const db = await openDb();
  const store = db.transaction(META, 'readwrite').objectStore(META);
  const meta = await wrap(store.get(id));
  if (meta) { meta.fav = !!value; if (!meta.fav) meta.hidden = false; await wrap(store.put(meta)); }
  db.close();
  try { window.dispatchEvent(new Event('fenix-history-changed')); } catch (e) { }
  return !!(meta && meta.fav);
}

export async function getMeta(id) {
  const all = await listReplays();
  return all.find((m) => m.id === id) || null;
}

// Quita la repeticion del Historial pero la conserva en Favoritos
export async function hideReplay(id) {
  const db = await openDb();
  const store = db.transaction(META, 'readwrite').objectStore(META);
  const meta = await wrap(store.get(id));
  if (meta) { meta.hidden = true; await wrap(store.put(meta)); }
  db.close();
  try { window.dispatchEvent(new Event('fenix-history-changed')); } catch (e) { }
}

// Guarda varios archivos a la vez (sin abrirlos). Devuelve cuántos eran nuevos.
export async function saveReplayFiles(files) {
  const before = new Set((await listReplays()).map((m) => m.id));
  let added = 0, failed = 0;
  for (const f of files) {
    try {
      const id = await saveReplayFile(f);
      if (id && !before.has(id)) { before.add(id); added++; }
    } catch (e) { failed++; }
  }
  try { window.dispatchEvent(new Event('fenix-history-changed')); } catch (e) { }
  return { added, total: files.length, failed };
}

// Datos del partido (marcador, duracion, estadio...) calculados al analizar la repeticion
export async function setReplayInfo(id, info) {
  if (!id || !info) return;
  try {
    const db = await openDb();
    const store = db.transaction(META, 'readwrite').objectStore(META);
    const meta = await wrap(store.get(id));
    if (meta && JSON.stringify(meta.info || null) !== JSON.stringify(info)) {
      meta.info = info;
      await wrap(store.put(meta));
      db.close();
      try { window.dispatchEvent(new Event('fenix-history-changed')); } catch (e) { }
      return;
    }
    db.close();
  } catch (e) { }
}

function b64FromBuf(buf) {
  const u = new Uint8Array(buf); let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}
function bufFromB64(b64) {
  const bin = atob(b64); const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u.buffer;
}

// Copia de seguridad: historial completo (metadatos + archivos) en un solo archivo
export async function exportAll() {
  const db = await openDb();
  const metas = await wrap(db.transaction(META).objectStore(META).getAll());
  const datas = await wrap(db.transaction(DATA).objectStore(DATA).getAll());
  db.close();
  const map = {};
  datas.forEach((d) => { map[d.id] = b64FromBuf(d.data); });
  return JSON.stringify({ app: 'os-fenix-replay', version: 1, created: Date.now(), items: metas.filter((m) => map[m.id]).map((m) => ({ meta: m, data: map[m.id] })) });
}

export async function importAll(text) {
  const obj = JSON.parse(text);
  if (!obj || obj.app !== 'os-fenix-replay' || !Array.isArray(obj.items)) throw new Error('Archivo no valido');
  const db = await openDb();
  const existing = await wrap(db.transaction(META).objectStore(META).getAll());
  const sigs = new Set(existing.map((m) => m.signature));
  const ids = new Set(existing.map((m) => m.id));
  let added = 0;
  const tx = db.transaction([META, DATA], 'readwrite');
  for (const it of obj.items) {
    const m = it.meta;
    if (!m || !m.id || ids.has(m.id) || (m.signature && sigs.has(m.signature))) continue;
    tx.objectStore(META).put(m);
    tx.objectStore(DATA).put({ id: m.id, data: bufFromB64(it.data) });
    added++;
  }
  await done(tx);
  db.close();
  try { window.dispatchEvent(new Event('fenix-history-changed')); } catch (e) { }
  return added;
}

