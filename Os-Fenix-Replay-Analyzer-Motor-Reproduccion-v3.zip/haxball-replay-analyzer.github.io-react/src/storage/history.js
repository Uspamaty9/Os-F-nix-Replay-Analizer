// Historial local de repeticiones (IndexedDB): funciona sin internet y sobrevive al cierre de la app.
const DB_NAME = 'os-fenix-replays';
const META = 'meta';
const DATA = 'data';

function openDb() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) { reject(new Error('IndexedDB no disponible')); return; }
    const req = window.indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(META)) db.createObjectStore(META, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(DATA)) db.createObjectStore(DATA, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function wrap(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function done(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function listReplays() {
  try {
    const db = await openDb();
    const all = await wrap(db.transaction(META).objectStore(META).getAll());
    db.close();
    return all.sort((a, b) => b.addedAt - a.addedAt);
  } catch (e) {
    return [];
  }
}

// Guarda el archivo original (sin modificarlo). Si ya existe el mismo archivo, solo lo sube al inicio.
export async function saveReplayFile(file) {
  const buffer = await file.arrayBuffer();
  const signature = [file.name, file.size, file.lastModified].join('|');
  const db = await openDb();
  const existing = await wrap(db.transaction(META).objectStore(META).getAll());
  const same = existing.find((m) => m.signature === signature);
  const tx = db.transaction([META, DATA], 'readwrite');
  let savedId = null;
  if (same) {
    same.addedAt = Date.now();
    tx.objectStore(META).put(same);
    savedId = same.id;
  } else {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    tx.objectStore(META).put({
      id,
      name: file.name.replace(/\.hbr2$/i, ''),
      fileName: file.name,
      size: file.size,
      signature,
      addedAt: Date.now(),
    });
    tx.objectStore(DATA).put({ id, data: buffer });
    savedId = id;
  }
  await done(tx);
  db.close();
  return savedId;
}

export async function getReplayData(id) {
  const db = await openDb();
  const rec = await wrap(db.transaction(DATA).objectStore(DATA).get(id));
  db.close();
  return rec ? rec.data : null;
}

export async function renameReplay(id, name) {
  const db = await openDb();
  const store = db.transaction(META, 'readwrite').objectStore(META);
  const meta = await wrap(store.get(id));
  if (meta) {
    meta.name = name.trim() || meta.fileName.replace(/\.hbr2$/i, '');
    await wrap(store.put(meta));
  }
  db.close();
}

export async function deleteReplay(id) {
  const db = await openDb();
  const tx = db.transaction([META, DATA], 'readwrite');
  tx.objectStore(META).delete(id);
  tx.objectStore(DATA).delete(id);
  await done(tx);
  db.close();
}

export async function setFavorite(id, value) {
  const db = await openDb();
  const store = db.transaction(META, 'readwrite').objectStore(META);
  const meta = await wrap(store.get(id));
  if (meta) { meta.fav = !!value; await wrap(store.put(meta)); }
  db.close();
  try { window.dispatchEvent(new Event('fenix-history-changed')); } catch (e) { }
  return !!(meta && meta.fav);
}

export async function getMeta(id) {
  const all = await listReplays();
  return all.find((m) => m.id === id) || null;
}
