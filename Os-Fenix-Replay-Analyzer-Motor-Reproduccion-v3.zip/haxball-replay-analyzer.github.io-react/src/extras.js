// Compartir imagen del partido
function cap() {
  const c = window.Capacitor;
  return c && c.isNativePlatform && c.isNativePlatform() && c.nativePromise ? c : null;
}

export function toast(msg) {
  const old = document.querySelector('.fenix-toast');
  if (old && old.parentNode) old.parentNode.removeChild(old);
  const t = document.createElement('div');
  t.className = 'fenix-toast';
  t.textContent = msg;
  document.body.appendChild(t);
  void t.offsetWidth;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
  setTimeout(() => { if (t.parentNode) t.parentNode.removeChild(t); }, 2900);
}

async function sendBytes(name, mime, b64, dest, share) {
  const c = cap();
  if (c) { await c.nativePromise('HbrScanner', 'shareBytes', { name, mime, data: b64, dest, share }); return true; }
  // Navegador: descarga directa
  const bin = atob(b64); const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([u], { type: mime }));
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); if (a.parentNode) a.parentNode.removeChild(a); }, 2000);
  return true;
}

// Imagen del partido para compartir (marcador, goleadores y estadísticas)
function cssVar(n, d) { try { const v = getComputedStyle(document.body).getPropertyValue(n).trim(); return v || d; } catch (e) { return d; } }
export async function shareSummaryImage(m, redName, blueName) {
  try {
    const W = 1080, H = 1350;
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d');
    const bg = cssVar('--bg', '#111111'), card = cssVar('--card', '#1b1b1b'), acc = cssVar('--acc', '#C89A3D'), txt = cssVar('--txt', '#F7F3E8'), red = cssVar('--red', '#7A0E1A');
    const grd = g.createRadialGradient(W / 2, 0, 50, W / 2, 0, 1100); grd.addColorStop(0, red); grd.addColorStop(1, bg);
    g.fillStyle = bg; g.fillRect(0, 0, W, H); g.fillStyle = grd; g.globalAlpha = 0.55; g.fillRect(0, 0, W, H); g.globalAlpha = 1;
    const img = await new Promise((res) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = (process.env.PUBLIC_URL || '') + '/brand/escudo.png'; });
    if (img) { const w = 230, h = w * img.height / img.width; g.drawImage(img, W / 2 - w / 2, 40, w, h); }
    g.textAlign = 'center'; g.fillStyle = acc; g.font = '600 34px Oswald, Arial'; g.fillText('REPLAY ANALIZER · OS FÊNIX', W / 2, 330);
    g.fillStyle = txt; g.font = '600 56px Oswald, Arial';
    const clip = (s, n) => (String(s).length > n ? String(s).slice(0, n - 1) + '…' : String(s));
    g.fillStyle = '#E56E56'; g.textAlign = 'right'; g.fillText(clip(redName, 14), 410, 450);
    g.fillStyle = '#5689E5'; g.textAlign = 'left'; g.fillText(clip(blueName, 14), 670, 450);
    g.fillStyle = txt; g.textAlign = 'center'; g.font = '700 150px Oswald, Arial'; g.fillText(m.scoreRed + ' - ' + m.scoreBlue, W / 2, 470);
    const secs = Math.max(0, Math.round((m.gameTicks || 0) / 60)); const tm = Math.floor(secs / 60) + ':' + String(secs % 60).padStart(2, '0');
    g.fillStyle = acc; g.font = '500 34px Poppins, Arial'; g.fillText('Duración ' + tm + (m.stadium && m.stadium.name ? ' · ' + clip(m.stadium.name, 26) : ''), W / 2, 530);
    // goles
    g.strokeStyle = acc; g.globalAlpha = 0.5; g.beginPath(); g.moveTo(120, 575); g.lineTo(W - 120, 575); g.stroke(); g.globalAlpha = 1;
    g.font = '600 38px Oswald, Arial'; g.fillStyle = acc; g.fillText('GOLES', W / 2, 625);
    let y = 680; g.font = '500 34px Poppins, Arial';
    (m.goals || []).slice(0, 7).forEach((gl) => {
      const label = gl.scorer + (gl.assist && gl.assist.player ? ' (' + gl.assist.player + ')' : '');
      const score = gl.currentScore ? gl.currentScore[0] + ':' + gl.currentScore[1] : '';
      g.fillStyle = txt; g.textAlign = 'center'; g.fillText(score, W / 2, y);
      g.fillStyle = gl.for === 'Red' ? '#E56E56' : '#5689E5';
      if (gl.for === 'Red') { g.textAlign = 'right'; g.fillText(clip(label, 24), W / 2 - 70, y); } else { g.textAlign = 'left'; g.fillText(clip(label, 24), W / 2 + 70, y); }
      y += 52;
    });
    // estadísticas
    y = Math.max(y + 20, 1010);
    const poss = (m.possRed + m.possBlue) > 0 ? Math.round(m.possRed / (m.possRed + m.possBlue) * 100) : 50;
    const rows = [['POSESIÓN', poss, 100 - poss, '%'], ['TOQUES', m.kicksRed, m.kicksBlue, ''], ['PASES', m.passesRed, m.passesBlue, ''], ['TIROS', m.shotsRed, m.shotsBlue, '']];
    rows.forEach((r, n) => {
      const yy = 1030 + n * 66;
      g.textAlign = 'right'; g.fillStyle = '#E56E56'; g.font = '600 36px Poppins, Arial'; g.fillText(r[1] + r[3], 230, yy);
      g.textAlign = 'left'; g.fillStyle = '#5689E5'; g.fillText(r[2] + r[3], W - 230, yy);
      g.textAlign = 'center'; g.fillStyle = txt; g.font = '500 28px Poppins, Arial'; g.fillText(r[0], W / 2, yy - 4);
      const tot = (r[1] + r[2]) || 1, bw = 560, bx = W / 2 - bw / 2;
      g.fillStyle = 'rgba(128,128,128,.3)'; g.fillRect(bx, yy + 8, bw, 8);
      g.fillStyle = '#E56E56'; g.fillRect(bx, yy + 8, bw * r[1] / tot, 8);
      g.fillStyle = '#5689E5'; g.fillRect(bx + bw * r[1] / tot, yy + 8, bw * r[2] / tot, 8);
    });
    const dataUrl = cv.toDataURL('image/png');
    await sendBytes('OsFenix-partido-' + Date.now() + '.png', 'image/png', dataUrl.split(',')[1], 'images', true);
    toast(cap() ? 'Imagen guardada en Imágenes/OsFenix' : 'Imagen descargada');
  } catch (e) { toast('No se pudo crear la imagen'); }
}
