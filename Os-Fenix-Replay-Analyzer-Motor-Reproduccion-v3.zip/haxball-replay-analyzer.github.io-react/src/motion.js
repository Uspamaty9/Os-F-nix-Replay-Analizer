// Animación de salida para paneles y ventanas que la app quita del DOM de golpe.
// Cuando uno de ellos desaparece, se vuelve a poner en su lugar unos milisegundos con la clase
// "fenix-leaving" (ver theme.scss) para que se desvanezca, y luego se retira de verdad.
const LEAVE = '.fs-overlay, .fh-rename-overlay, .fh-hbr-overlay, .fs-map-overlay, #game-stats, #room-view, .fh-menu, #greyer, .fh-edit';
const DUR = 240;

export function initMotion() {
  if (typeof MutationObserver === 'undefined' || typeof document === 'undefined') return;
  const timers = new WeakMap();
  const done = (n) => {
    const t = timers.get(n);
    if (t) clearTimeout(t);
    timers.delete(n);
    if (n.parentNode) n.parentNode.removeChild(n);
  };
  let obs = null;
  const handle = (records) => {
    for (const r of records) {
      for (const a of r.addedNodes) {
        if (a.nodeType !== 1) continue;
        if (a.classList.contains('fenix-leaving')) { // la app lo volvió a poner: cancelar la salida
          const t = timers.get(a); if (t) clearTimeout(t); timers.delete(a);
          a.classList.remove('fenix-leaving');
        }
        if (a.id) {
          document.querySelectorAll('.fenix-leaving').forEach((l) => { if (l !== a && l.id === a.id) done(l); });
        }
      }
      for (const n of r.removedNodes) {
        if (n.nodeType !== 1 || !n.matches || !n.matches(LEAVE) || n.classList.contains('fenix-leaving') || n.classList.contains('fenix-closing')) continue;
        const parent = r.target;
        if (!parent || !parent.isConnected || n.isConnected) continue;
        n.classList.add('fenix-leaving');
        const next = r.nextSibling && r.nextSibling.parentNode === parent ? r.nextSibling : null;
        try { parent.insertBefore(n, next); } catch (e) { continue; }
        timers.set(n, setTimeout(() => done(n), DUR));
      }
    }
    if (obs) obs.takeRecords(); // descarta los cambios que acabo de hacer yo
  };
  obs = new MutationObserver(handle);
  obs.observe(document.documentElement, { childList: true, subtree: true });
}
