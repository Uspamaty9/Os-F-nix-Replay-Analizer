import { createPortal } from 'react-dom';

// Ventana para ver un mapa en grande (se cierra tocando en cualquier parte)
export default function ZoomMap({ title, canvasRef, onClose }) {
  return createPortal(
    <div className='fs-map-overlay' onClick={onClose}>
      <div className='fs-map-box' onClick={(e) => e.stopPropagation()}>
        <div className='fs-map-head'>
          <span>{title}</span>
          <button type='button' className='fs-map-x' onClick={onClose}>Cerrar</button>
        </div>
        <canvas ref={canvasRef} width={1000} height={500} />
      </div>
    </div>,
    document.body
  );
}
