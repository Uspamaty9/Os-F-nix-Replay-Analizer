import { createPortal } from 'react-dom';
import { useEffect, useRef } from 'react';

// Ventana para ver un mapa en grande: se acerca pellizcando, se mueve con un dedo y el doble toque lo restablece
export default function ZoomMap({ title, canvasRef, onClose }) {
  const stage = useRef(null);

  useEffect(() => {
    const el = stage.current;
    if (!el) return undefined;
    const st = { z: 1, x: 0, y: 0 };
    const pts = new Map();
    let g = null, lastTap = 0;
    const cv = () => el.querySelector('canvas');
    const clamp = () => {
      const r = el.getBoundingClientRect();
      st.z = Math.min(6, Math.max(1, st.z));
      const mx = (r.width * (st.z - 1)) / 2, my = (r.height * (st.z - 1)) / 2;
      st.x = Math.min(mx, Math.max(-mx, st.x));
      st.y = Math.min(my, Math.max(-my, st.y));
    };
    const apply = () => { clamp(); const c = cv(); if (c) c.style.transform = 'translate(' + st.x + 'px,' + st.y + 'px) scale(' + st.z + ')'; };
    const dist = () => { const a = Array.from(pts.values()); return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) || 1; };
    const down = (e) => {
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      try { el.setPointerCapture(e.pointerId); } catch (x) { }
      if (pts.size === 2) g = { type: 'pinch', d0: dist(), z0: st.z };
      else if (pts.size === 1) {
        const now = performance.now();
        if (now - lastTap < 300) { st.z = 1; st.x = 0; st.y = 0; apply(); lastTap = 0; }
        else lastTap = now;
        g = { type: 'pan', lx: e.clientX, ly: e.clientY };
      }
    };
    const move = (e) => {
      if (!pts.has(e.pointerId)) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (!g) return;
      if (g.type === 'pinch' && pts.size >= 2) { st.z = g.z0 * dist() / g.d0; apply(); }
      else if (g.type === 'pan' && pts.size === 1 && st.z > 1) { st.x += e.clientX - g.lx; st.y += e.clientY - g.ly; g.lx = e.clientX; g.ly = e.clientY; apply(); }
    };
    const up = (e) => {
      pts.delete(e.pointerId);
      if (pts.size === 1) { const p = Array.from(pts.values())[0]; g = { type: 'pan', lx: p.x, ly: p.y }; }
      else if (pts.size === 0) g = null;
    };
    const wheel = (e) => { e.preventDefault(); st.z *= Math.exp(-e.deltaY * 0.0015); apply(); };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('wheel', wheel, { passive: false });
    return () => {
      el.removeEventListener('pointerdown', down); el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up);
      el.removeEventListener('wheel', wheel);
    };
  }, []);

  return createPortal(
    <div className='fs-map-overlay' onClick={onClose}>
      <div className='fs-map-box' onClick={(e) => e.stopPropagation()}>
        <div className='fs-map-head'>
          <span>{title}</span>
          <button type='button' className='fs-map-x' onClick={onClose}>Cerrar</button>
        </div>
        <div className='fs-map-stage' ref={stage}>
          <canvas ref={canvasRef} width={1000} height={500} />
        </div>
        <p className='fs-map-hint'>Pellizca para acercar · doble toque para restablecer</p>
      </div>
    </div>,
    document.body
  );
}
