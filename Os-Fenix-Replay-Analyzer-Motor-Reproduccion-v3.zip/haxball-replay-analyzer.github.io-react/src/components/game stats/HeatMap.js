/* eslint-disable react-hooks/exhaustive-deps */
import { useSelector } from 'react-redux';
import { useRef, useEffect, useState } from 'react';
import ZoomMap from './ZoomMap';
import { drawStadium } from './StadiumCanvas';

function HeatMap({ arrow }) {

  const match = useSelector(state => state.gameStats.matches)
  const mtc = useSelector(state => state.gameStats.selectedMatch)
  const playerPos = useSelector(state => state.gameStats.playerPos)
  const playerList = useSelector(state => state.gameStats.playerList)
  const selectedPlayer = useSelector(state => state.gameStats.selectedPlayer)
  const selectedHeatmap = useSelector(state => state.gameStats.selectedHeatmap)
  const stadium = match[mtc].stadium
  const canvasRef = useRef(null);
  const bigRef = useRef(null);
  const [big, setBig] = useState(false);

  function drawArrow(ctx, from, to) {
    var headlen = 15; // length of head in pixels
    var dx = to.x - from.x;
    var dy = to.y - from.y;
    var angle = Math.atan2(dy, dx);
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.lineTo(to.x - headlen * Math.cos(angle - Math.PI / 6), to.y - headlen * Math.sin(angle - Math.PI / 6));
    ctx.moveTo(to.x, to.y);
    ctx.lineTo(to.x - headlen * Math.cos(angle + Math.PI / 6), to.y - headlen * Math.sin(angle + Math.PI / 6));
    ctx.stroke();
  }

  function draw(ctx, sc = 1) {

    drawStadium(ctx, stadium, sc);

    var player = selectedPlayer;
    if (player === -1) player = match[mtc].redTeam[0];

    if (selectedHeatmap === 'Heatmap') {
      // Recorrido del jugador: una línea fina; cada vez que vuelve a pasar por el mismo sitio el rojo se intensifica
      const pos = playerPos[mtc][playerList.indexOf(player)];
      if (pos === undefined || pos.length === 0) return;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      var prev = pos[0];
      for (var i = 1; i < pos.length; i++) {
        var p = pos[i];
        var dx = p.x - prev.x, dy = p.y - prev.y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < 4) continue;
        if (d < 160) {
          ctx.beginPath();
          ctx.moveTo(prev.x, prev.y);
          ctx.lineTo(p.x, p.y);
          ctx.strokeStyle = 'rgba(255, 30, 20, 0.2)';
          ctx.lineWidth = 5;
          ctx.stroke();
        }
        prev = p;
      }
      // inicio y final del recorrido
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.strokeStyle = 'rgba(0,0,0,0.9)';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(pos[0].x, pos[0].y, 6, 0, 2 * Math.PI); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(255,40,30,1)';
      ctx.beginPath(); ctx.arc(pos[pos.length - 1].x, pos[pos.length - 1].y, 6, 0, 2 * Math.PI); ctx.fill(); ctx.stroke();
    } else {
      const stat = selectedHeatmap.split(' ')[0];
      if (stat === 'Goals') {
        for (let goal of match[mtc].goals) {
          if (goal.scorer == player) {
            ctx.beginPath();
            ctx.strokeStyle = 'red';
            ctx.lineWidth = 5;
            ctx.moveTo(goal.shot.x, goal.shot.y);
            ctx.lineTo(goal.ballCoord.x, goal.ballCoord.y);
            ctx.stroke();
          }
        }
      } else if (stat === 'Assists') {
        for (let goal of match[mtc].goals) {
          if (goal.assist?.player === player) {
            ctx.beginPath();
            ctx.strokeStyle = 'red';
            ctx.lineWidth = 5;
            ctx.moveTo(goal.assist.shot.x, goal.assist.shot.y);
            ctx.lineTo(goal.shot.x, goal.shot.y);
            ctx.lineTo(goal.ballCoord.x, goal.ballCoord.y);
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(goal.shot.x, goal.shot.y, 10, 0, 2 * Math.PI)
            ctx.fillStyle = 'red'
            ctx.fill();
          }
        }
      } else if (stat === 'Kicks') {
        for (let kick of match[mtc].kicks) {
          if (kick.player === player) {
            ctx.beginPath();
            ctx.fillStyle = 'red'
            ctx.arc(kick.x, kick.y, 5, 0, 2 * Math.PI)
            ctx.fill();
          }
        }
      } else if (stat === 'Passes') {
        for (let pass of match[mtc].passes) {
          if (pass.player === player) {
            ctx.beginPath();
            ctx.strokeStyle = 'red';
            ctx.lineWidth = 5;
            drawArrow(ctx, pass.lastShot, pass.shot)
          }
        }
      } else if (stat === 'Shots') {
        for (let shot of match[mtc].shots) {
          if (shot.player === player) {
            ctx.beginPath();
            ctx.strokeStyle = 'red';
            ctx.lineWidth = 5;
            drawArrow(ctx, shot.from, shot.to)
          }
        }
      }
    }
  };

  useEffect(() => {

    const canvas = canvasRef.current
    const context = canvas.getContext('2d')

    draw(context)
  }, [draw])

  useEffect(() => {
    if (!big || !bigRef.current) return;
    draw(bigRef.current.getContext('2d'), 2)
  }, [big, selectedHeatmap, selectedPlayer])

  const ES = { Heatmap: 'Mapa de calor', Goals: 'Goles', Assists: 'Asistencias', Kicks: 'Toques', Passes: 'Pases', Shots: 'Tiros' };
  const pl = selectedPlayer === -1 ? match[mtc].redTeam[0] : selectedPlayer;
  return (
    <>
      <div className='fs-map-body'><canvas ref={canvasRef} width={500} height={250} className='fs-map-canvas' onClick={() => setBig(true)} style={{ display: 'block', margin: '0 auto', width: '100%', height: 'auto' }} ></canvas>{arrow}</div>
      {big && <ZoomMap title={(ES[selectedHeatmap.split(' ')[0]] || selectedHeatmap) + ' de ' + pl} canvasRef={bigRef} onClose={() => setBig(false)} />}
    </>
  );
}

export default HeatMap;