/* eslint-disable react-hooks/exhaustive-deps */
import { useSelector } from 'react-redux';
import { useRef, useEffect, useState } from 'react';
import { drawStadium } from './StadiumCanvas';
import ZoomMap from './ZoomMap';

function ThirdStats({ arrow }) {

  const match = useSelector(state => state.gameStats.matches);
  const mtc = useSelector(state => state.gameStats.selectedMatch)
  const stadium = match[mtc].stadium
  const canvasRef = useRef(null);
  const bigRef = useRef(null);
  const [big, setBig] = useState(false);

  function draw(ctx, sc = 1) {

    drawStadium(ctx, stadium, sc);
    ctx.setTransform(sc, 0, 0, sc, 0, 0)
    ctx.font = "45px Arial";
    ctx.fillStyle = "rgba(0, 0, 0, 0.1)";
    ctx.fillRect(175, 0, 150, 250);
    ctx.fillStyle = "rgba(255, 255, 255, 1)";
    ctx.strokeStyle = "rgba(0, 0, 0, 1)";
    ctx.lineWidth = 8;

    for (var i = 0; i < 3; i++) {
      ctx.strokeText("" + Math.round(100 * (match[mtc].thirds[i] / (match[mtc].thirds[0] + match[mtc].thirds[1] + match[mtc].thirds[2]))) + "%", 70 + 140 * i, 147);
      ctx.fillText("" + Math.round(100 * (match[mtc].thirds[i] / (match[mtc].thirds[0] + match[mtc].thirds[1] + match[mtc].thirds[2]))) + "%", 70 + 140 * i, 147);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current
    const context = canvas.getContext('2d')
    draw(context)
  }, [draw])

  useEffect(() => {
    if (!big || !bigRef.current) return;
    draw(bigRef.current.getContext('2d'), 2)
  }, [big])

  return (
    <>
      <p className='fs-map-title fs-map-heat'><b>Mapa de posesión</b><span>Por zonas del campo</span></p>
      <div className='fs-map-body'><canvas ref={canvasRef} width={500} height={250} className='fs-map-canvas fs-map-static' style={{ display: 'block', margin: '0 auto', width: '100%', height: 'auto' }} ></canvas>{arrow}</div>
      {big && <ZoomMap title='Posesión por zonas' canvasRef={bigRef} onClose={() => setBig(false)} />}
    </>
  );
}

export default ThirdStats;
