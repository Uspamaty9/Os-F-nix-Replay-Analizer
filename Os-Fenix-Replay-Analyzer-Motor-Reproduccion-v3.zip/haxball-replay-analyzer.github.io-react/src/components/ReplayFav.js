import { useEffect } from 'react';
import { getMeta, setFavorite } from '../storage/history';

// La estrella vive junto al indicador de zoom (la crea game2.js); aquí solo se conecta con el historial
function paint(on) {
  window.__fenixFavOn = on;
  const s = document.querySelector('.fenix-star');
  if (s) {
    s.classList.toggle('on', on);
    const p = s.querySelector('svg');
    if (p) p.setAttribute('fill', on ? 'currentColor' : 'none');
  }
}

export default function ReplayFav() {
  useEffect(() => {
    let lastId = null;
    const load = () => {
      const id = window.__fenixCurrentId || null;
      if (!id) { paint(false); return; }
      getMeta(id).then((m) => paint(!!(m && m.fav)));
    };
    window.__fenixToggleFav = async () => {
      const id = window.__fenixCurrentId;
      if (!id) return;
      const next = !window.__fenixFavOn;
      paint(next);
      await setFavorite(id, next);
    };
    const t = setInterval(() => {
      const id = window.__fenixCurrentId || null;
      const s = document.querySelector('.fenix-star');
      if (id !== lastId || (s && s.dataset.painted !== String(!!window.__fenixFavOn))) {
        lastId = id; load();
        if (s) s.dataset.painted = String(!!window.__fenixFavOn);
      }
    }, 400);
    window.addEventListener('fenix-history-changed', load);
    return () => { clearInterval(t); window.removeEventListener('fenix-history-changed', load); };
  }, []);
  return null;
}
