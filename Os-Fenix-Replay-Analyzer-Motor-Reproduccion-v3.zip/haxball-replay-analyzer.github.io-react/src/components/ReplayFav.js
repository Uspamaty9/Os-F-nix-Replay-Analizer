import { useEffect, useState } from 'react';
import { getMeta, setFavorite } from '../storage/history';

// Estrella para guardar en favoritos la repetición que se está viendo
export default function ReplayFav() {
  const [visible, setVisible] = useState(false);
  const [id, setId] = useState(null);
  const [fav, setFav] = useState(false);

  useEffect(() => {
    const t = setInterval(() => {
      const cur = window.__fenixCurrentId || null;
      const gv = document.querySelector('.game-view');
      const on = !!(cur && gv && gv.getBoundingClientRect().left < 40);
      setVisible(on);
      setId((p) => (p === cur ? p : cur));
    }, 400);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let alive = true;
    const load = () => { if (id) getMeta(id).then((m) => { if (alive) setFav(!!(m && m.fav)); }); };
    load();
    window.addEventListener('fenix-history-changed', load);
    return () => { alive = false; window.removeEventListener('fenix-history-changed', load); };
  }, [id]);

  if (!visible) return null;
  return (
    <button className={'fh-replay-star' + (fav ? ' on' : '')} aria-label={fav ? 'Quitar de favoritos' : 'Agregar a favoritos'}
      onClick={() => { const n = !fav; setFav(n); setFavorite(id, n); }}>
      <svg width='26' height='26' viewBox='0 0 24 24' fill={fav ? 'currentColor' : 'none'} stroke='currentColor' strokeWidth='2' strokeLinejoin='round'><path d='M12 3.2l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17.2 6.6 20.1l1-6.1L3.2 9.7l6.1-.9z' /></svg>
    </button>
  );
}
