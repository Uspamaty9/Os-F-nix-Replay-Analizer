function Downloading() {

  return (
    <div id='downloading-screen' className="loading fenix-wait">
      <div className='fw-crest'>
        <span className='fw-ring' aria-hidden='true' />
        <img src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt='' />
      </div>
      <h1>Cargando repetición…</h1>
      <p className='fw-sub'>Leyendo el archivo guardado.</p>
    </div>
  );
}

export default Downloading;
