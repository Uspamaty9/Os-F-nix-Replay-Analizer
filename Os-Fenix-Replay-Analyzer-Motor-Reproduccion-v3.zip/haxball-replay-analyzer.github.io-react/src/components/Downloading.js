function Downloading() {

  return (
    <div id='downloading-screen' className="loading">
      <span className='spinner' aria-hidden='true' />
      <h1>Cargando repetición…</h1>
      Leyendo el archivo guardado.
    </div>
  );
}

export default Downloading;