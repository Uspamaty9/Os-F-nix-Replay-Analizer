// Pantalla "Analizando…": escudo de Os Fênix con anillo animado y un dato del club
function LoadingScreen() {
  return (
    <div id='loading-screen' className="loading fenix-wait">
      <div className='fw-crest'>
        <span className='fw-ring' aria-hidden='true' />
        <img src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt='' />
      </div>
      <h1>Analizando…</h1>
      <p className='fw-sub'>Un momento, puede tardar unos segundos.</p>
      <div className='fw-fact'>
        <span className='fw-fact-tag'>Dato del club</span>
        <p>Aquí aparecerá un dato aleatorio de Os Fênix mientras se analiza la repetición.</p>
      </div>
    </div>
  );
}

export default LoadingScreen;
