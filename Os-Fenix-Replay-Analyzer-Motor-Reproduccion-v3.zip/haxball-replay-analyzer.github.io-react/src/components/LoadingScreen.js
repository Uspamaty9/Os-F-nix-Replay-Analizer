import { useState, useEffect } from 'react';

// Pantalla "Analizando…": escudo de Os Fênix con anillo animado, un dato del club y consejos de uso debajo
const TIPS = [
  ['🎯', 'Seguir jugador', 'Toca el botón de seguir para que la cámara persiga a un jugador o a la pelota.'],
  ['📺', 'Cámara Auto TV', 'Elige Auto TV y la cámara se mueve sola, como en una transmisión de fútbol.'],
  ['🎥', 'Graba tu jugada', 'Con el botón de cámara grabas la repetición y se guarda en tu galería.'],
  ['👁', 'Pantalla despejada', 'Oculta los botones para ver solo la cancha. Toca 2 veces para volver.'],
  ['🔍', 'Zoom', 'Pellizca la cancha para acercar y arrastra con un dedo para moverte.'],
  ['⚙️', 'Tu repetición, a tu gusto', 'En Ajustes puedes ocultar chat, nombres y flechas, y cambiar su tamaño.'],
  ['⭐', 'Favoritos', 'Marca con la estrella las repeticiones que quieras conservar siempre.'],
  ['🎨', 'Temas', 'Cambia los colores de la app en Configuración: Default, Torneos o el tuyo.'],
];

function LoadingScreen() {
  const [n, setN] = useState(() => Math.floor(Math.random() * TIPS.length));
  useEffect(() => { const t = setInterval(() => setN((v) => (v + 1) % TIPS.length), 3600); return () => clearInterval(t); }, []);
  const tip = TIPS[n];
  return (
    <div id='loading-screen' className="loading fenix-wait">
      <div className='fw-crest'>
        <span className='fw-ring' aria-hidden='true' />
        <img src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt='' />
      </div>
      <h1>Analizando…</h1>
      <p className='fw-sub'>Un momento, puede tardar unos segundos.</p>
      <p className='fw-tap'>Toca la pantalla para continuar</p>
      <div className='fw-tips' aria-live='off'>
        <div className='fw-tip' key={n}>
          <span className='fw-tip-ico'>{tip[0]}</span>
          <div className='fw-tip-tx'><b>{tip[1]}</b><p>{tip[2]}</p></div>
        </div>
        <div className='fw-dots'>{TIPS.map((t, i) => <i key={i} className={i === n ? 'on' : ''} />)}</div>
      </div>
      <div className='fw-fact'>
        <span className='fw-fact-tag'>Dato del club</span>
        <p>Aquí aparecerá un dato aleatorio de Os Fênix mientras se analiza la repetición.</p>
      </div>
    </div>
  );
}

export default LoadingScreen;
