function LoadingScreen() {

  return (
    <div id='loading-screen' className="loading">
      <h1>Analizando…</h1>
      Un momento, puede tardar unos segundos.
    </div>
  );
}

export default LoadingScreen;
