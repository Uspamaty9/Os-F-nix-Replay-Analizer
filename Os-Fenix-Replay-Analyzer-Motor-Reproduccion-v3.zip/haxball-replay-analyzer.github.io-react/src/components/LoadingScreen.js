// Pantalla "Analizando…": escudo de Os Fênix con anillo animado y un dato del club
function LoadingScreen() {
  return (
    <div id='loading-screen' className="loading fenix-wait">
      <div className='fw-crest'>
        <span className='fw-ring' aria-hidden='true' />
        <img src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt='' />
      </div>
      <h1>Analizando…</h1>
      <p className='fw-sub'>Un momento, puede tardar unos segundos.</p>
      <p className='fw-tap'>Toca la pantalla para continuar</p>
      <div className='fw-scene' aria-hidden='true'>
        <div className='fw-embers'><i /><i /><i /><i /><i /><i /><i /></div>
        <div className='fw-grass' />
        <div className='fw-goal'><span className='fw-net' /></div>
        <div className='fw-ballx'><div className='fw-bally'><span className='fw-ball' /></div></div>
        <div className='fw-confetti'><i style={{ '--dx': '-34px', '--dy': '-58px', '--c': '#C89A3D', animationDelay: '0.00s' }} /><i style={{ '--dx': '-12px', '--dy': '-76px', '--c': '#fff', animationDelay: '0.00s' }} /><i style={{ '--dx': '14px', '--dy': '-70px', '--c': '#E56E56', animationDelay: '0.00s' }} /><i style={{ '--dx': '36px', '--dy': '-52px', '--c': '#C89A3D', animationDelay: '0.00s' }} /><i style={{ '--dx': '-46px', '--dy': '-30px', '--c': '#5689E5', animationDelay: '0.00s' }} /><i style={{ '--dx': '46px', '--dy': '-26px', '--c': '#fff', animationDelay: '0.00s' }} /><i style={{ '--dx': '-24px', '--dy': '-44px', '--c': '#E56E56', animationDelay: '0.00s' }} /><i style={{ '--dx': '26px', '--dy': '-40px', '--c': '#C89A3D', animationDelay: '0.00s' }} /></div>
        <div className='fw-gol'>¡GOOOL!</div>
      </div>
      <div className='fw-fact'>
        <span className='fw-fact-tag'>Dato del club</span>
        <p>Aquí aparecerá un dato aleatorio de Os Fênix mientras se analiza la repetición.</p>
      </div>
    </div>
  );
}

export default LoadingScreen;
