import HistoryList from "./HistoryList";
import { saveReplayFile, getReplayData } from "../storage/history";
import $ from 'jquery'
import { handleFile, replayFromSite } from "../game2.js";
import LoadingScreen from "./LoadingScreen";
import { useSelector, useDispatch } from "react-redux";
import { setMainMode, setUserUploaded } from "../slices/mainModeSlice";
import { setDivStyle, setStats, setPlayerList, setPlayerPos, clearStats, setConnectHalves, setRedTeamName, setBlueTeamName, setConnectedHalves } from "../slices/gameStatsSlice";
import GameStats from "./game stats/GameStats";
import useWebSocket, { ReadyState } from 'react-use-websocket';
import { useEffect, useState } from "react";
import ReplaysList from "./replays/ReplaysList";
import { setReplays, setReplaysLoaded, setReplaysType, setLoadingMore, addMoreReplays } from "../slices/replaysSlice";
import { openModal } from "./Modal";
import Downloading from "./Downloading";
import SettingsSheet from './SettingsSheet';
import ReplayFav from './ReplayFav';

export function showStats() { }
export function setGameStats() { }
export function dispatchPlayerList() { }
export function dispatchPlayerPos() { }
export function dispatchClearStats() { }
export function sendSocketMessage() { }
export function sendMessageExp() { }
export function search4Replays() { }
export function checkParamsExp() { }
export function changeTeamNames() { }
export function loadMoreReplays() { }

var queryMessage = {};
var replayData = [];
var waitingForStats = true;
var waitingForSocket = true;
var replayIdToSend;

function Home() {

  const socketUrl = 'wss://haxball-replay-analyzer.com:443/';
  // const socketUrl = 'ws://haxball-replay-analyzer.com:8080/';
  // const socketUrl = 'ws://localhost:8080/';
  const STATIC_OPTIONS = {
    onOpen: () => {
      // console.log('Connected with WebSocket')
      getWebSocket().onmessage = ev => receiveMessage(ev);
      if (!paramsChecked) {
        checkParams();
        setParamsChecked(true)
      }
    },
    onClose: (e) => {
      console.log('Connection closed', e.reason);
    },
    shouldReconnect: (closeEvent) => false
  }
  const { sendMessage, readyState, getWebSocket } = useWebSocket(socketUrl, STATIC_OPTIONS, false);
  const connectionStatus = {
    [ReadyState.CONNECTING]: 'Connecting',
    [ReadyState.OPEN]: 'Open',
    [ReadyState.CLOSING]: 'Closing',
    [ReadyState.CLOSED]: 'Closed',
    [ReadyState.UNINSTANTIATED]: 'Uninstantiated',
  }[readyState];

  const dispatch = useDispatch();
  const mainMode = useSelector((state) => state.mainMode.value);
  const version = useSelector((state) => state.mainMode.version);
  const userDidUpload = useSelector(state => state.mainMode.userUploaded);
  const [replayId, setReplayId] = useState(null);
  const [replayName, setReplayName] = useState(null);
  const [replayLastModified, setLastModified] = useState(null);
  const [paramsChecked, setParamsChecked] = useState(false);
  const [IP, setIP] = useState(null);
  const [historyTick, setHistoryTick] = useState(0);
  const filterPlayer = useSelector(state => state.replays.filters.player)
  const filterTeam = useSelector(state => state.replays.filters.team)
  const filterReplay = useSelector(state => state.replays.filters.replay)
  const filterGoal = useSelector(state => state.replays.filters.goal)
  const filterStadium = useSelector(state => state.replays.filters.stadium)
  const filterSpaceMode = useSelector(state => state.replays.filters.spaceMode)
  const filterRealSoccer = useSelector(state => state.replays.filters.realSoccer)
  const searchText = useSelector(state => state.replays.filters.searchText)
  const periodState = useSelector(state => state.replays.filters.period)
  const replaysType = useSelector(state => state.replays.type);
  const replays = useSelector(state => state.replays.replays);
  const replaysQty = replays.replays?.length;
  const startDate = useSelector(state => state.replays.filters.startDate)
  const endDate = useSelector(state => state.replays.filters.endDate)

  function receiveMessage(m) {
    const x = JSON.parse(m.data);
    // console.log(x);
    if (x.header === 'insertedReplayId') {
      const addURL = "?replayId=" + x.id;
      window.history.pushState(null, null, addURL);
      setReplayId(x.id);
      waitingForSocket = false;
      replayIdToSend = x.id;
      if (!waitingForStats) {
        sendMessage(JSON.stringify(queryMessage));
      }
    } else if (x.header === 'replayPart') {
      replayData = replayData.concat(x.rec.data);
    } else if (x.header === 'replaySent') {
      if (x?.connectHalves) dispatch(setConnectHalves(true))
      else dispatch(setConnectHalves(false))

      for (var i = 0; i < x.teamNames.length; i++) {
        const j = Math.floor(i / 2);
        if (i % 2 === 0) {
          dispatch(setRedTeamName({ mtc: j, name: x.teamNames[i].TeamName }))
        } else dispatch(setBlueTeamName({ mtc: j, name: x.teamNames[i].TeamName }))
      }

      const y = replayData;
      const buffer = new ArrayBuffer(y.length);
      const uint8View = new Uint8Array(buffer);
      for (let i = 0; i < y.length; i++) {
        uint8View[i] = y[i]; // zapisywanie danych z tablicy do bufora ArrayBuffer
      }
      const newBuffer = uint8View.buffer; // konwersja widoku Uint8Array na ArrayBuffer
      dispatch(setUserUploaded(false));
      replayData = [];

      $(function () {

        $('#downloading-screen').animate({
          left: '-150%',
        }, { duration: 700, easing: 'swing', queue: false, complete: function () { $("#downloading-screen").css('left', '100%') } });

        $('#loading-screen').animate({
          left: '8vw',
        }, { duration: 700, easing: 'swing', queue: false, complete: function () { replayFromSite(newBuffer); } });

      })
    } else if (x.header === 'alreadyUploaded') {
      const addURL = "?replayId=" + x.replayId;
      window.history.pushState(null, null, addURL);
      setReplayId(x.id);
      openModal('This recording has already been uploaded. Redirected to this replay.', 'darkgoldenrod', 5)
    } else if (x.header === 'top10 stats') {
      for (var i = 0; i < x.replays.replays.length; i++) {
        if (x.replays.replays[i].ConnectedHalves) {
          connectHalves(x.replays, i)
        }
      }
      // console.log(x.replays);
      dispatch(setReplaysLoaded(true));
      dispatch(setReplays(x.replays));
      dispatch(setMainMode('replays'));
    } else if (x.header === 'invalidLink') {
      openModal('Invalid link - replay with given ID doesn\'t exist', 'darkgoldenrod', 4)
    } else if (x.header === 'next10 stats') {
      for (var i = 0; i < x.replays.replays.length; i++) {
        if (x.replays.replays[i].ConnectedHalves) {
          connectHalves(x.replays, i)
        }
      }
      if (x.replays.replays.length > 0) dispatch(addMoreReplays(x.replays));
      dispatch(setLoadingMore(false))
    }
  }

  function connectHalves(replays, i) {
    const firstMatchId = replays.matches[i][0].MatchId;
    const firstTeamId = replays.teams[i][0].TeamId;
    const teamIds = [firstTeamId, firstTeamId + 1, firstTeamId + 2, firstTeamId + 3]
    for (let goal of replays.goals[i]) {
      goal.MatchId = firstMatchId;
    }
    replays.matches[i][0].RedScore += replays.matches[i][1].BlueScore;
    replays.matches[i][0].BlueScore += replays.matches[i][1].RedScore;
    replays.matches[i].splice(1, 1);
    var tempPlayers = [];
    for (let player of replays.players[i]) {
      if (!tempPlayers.includes(player.Nick)) {
        if (player.TeamId === teamIds[2]) player.TeamId = teamIds[1];
        if (player.TeamId === teamIds[3]) player.TeamId = teamIds[0];
      }
      tempPlayers.push(player.Nick)
    }
  }

  function checkParams() {
    const params = window.location.toLocaleString().split('?replayId=');
    if (params.length > 1) {
      const toSend = {
        header: 'select',
        id: params[1]
      }
      sendMessage(JSON.stringify(toSend))
      $(function () {

        $('.roomlist-view').animate({
          left: '-150%',
        }, { duration: 700, easing: 'swing', queue: false });

        $('#downloading-screen').animate({
          left: '8vw',
        }, { duration: 700, easing: 'swing', queue: false });

      })
    }
  }

  function showReplays(ev) {
    // console.log('showreplays');
    if (connectionStatus === 'Open') {
      if (ev.target.textContent === 'Most viewed replays') {
        var replaysType = 'mostViewed'
      } else {
        var replaysType = 'latest'
      }

      dispatch(setReplaysType(replaysType))

      const toSend = {
        header: 'top10',
        period: 'week',
        replaysType: replaysType
      }
      sendMessage(JSON.stringify(toSend))
    } else if (connectionStatus === 'Connecting') {
      openModal('Connecting to server... Please try again after few seconds.', 'darkgoldenrod', 4)
    } else {
      openModal('Error: Can\'t connect to server. Try again later.', 'darkred', 4)
    }
  }

  async function getIP() {
    const response = await fetch('https://ipapi.co/json/')
    const data = await response.json();
    setIP(data.ip)
  }

  function showStatsExp(elStyle) {
    const { offsetLeft, offsetTop, clientWidth, clientHeight } = elStyle;
    const offsetParentTop = elStyle.offsetParent ? elStyle.offsetParent.offsetTop : 0;
    dispatch(setDivStyle({ offsetLeft, offsetTop, offsetParentTop, clientWidth, clientHeight }));
    dispatch(setMainMode('stats'));
  }

  function setGameStatsExp(stats) {
    dispatch(setStats(stats));
    if (userDidUpload) {
      var message = [];
      for (var i = 0; i < stats.length; i++) {
        const match = stats[i];
        dispatch(setRedTeamName({ mtc: i, name: 'RED' }))
        dispatch(setBlueTeamName({ mtc: i, name: 'BLUE' }))
        message.push({
          blueTeam: match.blueTeam,
          goals: match.goals,
          redTeam: match.redTeam,
          scoreBlue: match.scoreBlue,
          scoreRed: match.scoreRed,
          spaceMode: match.spaceMode,
          realSoccerMode: match.realSoccerMode,
          stadiumName: match.stadium.name
        })
      }
      const toSend = {
        header: 'setStats',
        stats: message,
        replayId: replayIdToSend,
        replayName: replayName,
        lastModified: replayLastModified,
        IP: IP
      }
      queryMessage = toSend;
      waitingForStats = false;
      if (!waitingForSocket) {
        sendMessage(JSON.stringify(queryMessage))
      }
    }
  }

  function setPlayerListExp(el) {
    dispatch(setPlayerList(el));
  }

  function setPlayerPosExp(el) {
    dispatch(setPlayerPos(el));
  }

  function dispatchClearStatsExp() {
    dispatch(clearStats());
  }

  changeTeamNames = function (names, matchId) {
    const toSend = {
      header: 'changeTeamNames',
      names: names,
      matchId: matchId,
      replayId: replayId
    }
    sendMessage(JSON.stringify(toSend))
  }

  loadMoreReplays = function (a) {
    const toSend = {
      header: 'next10 filtered',
      replaysType: replaysType,
      searchText: searchText,
      filterPlayer: filterPlayer,
      filterGoal: filterGoal,
      filterRealSoccer: filterRealSoccer,
      filterReplay: filterReplay,
      filterSpaceMode: filterSpaceMode,
      filterStadium: filterStadium,
      filterTeam: filterTeam,
      period: periodState,
      alreadyLoaded: replaysQty,
      startDate: startDate,
      endDate: endDate
    }
    sendMessage(JSON.stringify(toSend))
  }

  sendMessageExp = function (m) {
    sendMessage(JSON.stringify(m))
  }

  sendSocketMessage = function (m, n, o) {
    setReplayName(n);
    if (m.byteLength > 50_000) {
      var replayParts = [];
      var x = new Uint8Array(m);
      x = Array.from(x)
      do {
        replayParts.push(x.splice(0, 50_000))
      } while (x.length > 50_000)
      replayParts.push(x);
      for (let part of replayParts) {
        const buffer = new ArrayBuffer(part.length);
        const uint8View = new Uint8Array(buffer);
        for (let i = 0; i < part.length; i++) {
          uint8View[i] = part[i]; // zapisywanie danych z tablicy do bufora ArrayBuffer
        }
        const newBuffer = uint8View.buffer;
        sendMessage(newBuffer)
      }
    } else {
      sendMessage(m)
    }
    const toSend = {
      header: 'replaySent'
    }
    sendMessage(JSON.stringify(toSend))
    setLastModified(o);
  }

  search4Replays = function (toSend) {
    dispatch(setReplaysLoaded(false));
    sendMessage(JSON.stringify(toSend))
  }

  showStats = showStatsExp;
  setGameStats = setGameStatsExp;
  dispatchPlayerList = setPlayerListExp;
  dispatchPlayerPos = setPlayerPosExp;
  dispatchClearStats = dispatchClearStatsExp;
  checkParamsExp = function () {
    checkParams();
  }

  async function openSaved(id) {
    const data = await getReplayData(id);
    if (!data) return;
    window.__fenixCurrentId = id;
    dispatch(setUserUploaded(true));
    dispatch(setConnectHalves(false))
    dispatch(setConnectedHalves(false))
    setReplayId(null);
    waitingForSocket = true;
    waitingForStats = true;
    $(function () {
      $('.roomlist-view').animate({
        left: '-150%',
      }, { duration: 700, easing: 'swing', queue: false });
      $('#loading-screen').animate({
        left: '8vw',
      }, { duration: 700, easing: 'swing', queue: false, complete: function () { replayFromSite(data) } });
    })
  }

  function callbackFn(e) {
    handleFile(e);
  }

  function nativeCap() {
    const cap = window.Capacitor;
    return cap && cap.isNativePlatform && cap.isNativePlatform() && cap.nativePromise ? cap : null;
  }

  // En el celular se abre el selector del sistema directamente en Descargas
  async function openImport() {
    const cap = nativeCap();
    if (!cap) { const inp = document.getElementById('replayfile'); if (inp) inp.click(); return; }
    try {
      const r = await cap.nativePromise('HbrScanner', 'pick', {});
      const bin = atob(r.data);
      const bytes = new Uint8Array(bin.length);
      for (let k = 0; k < bin.length; k++) bytes[k] = bin.charCodeAt(k);
      const file = new File([bytes], r.name || 'repeticion.hbr2', { lastModified: Date.now() });
      handleChange({ target: { files: [file], value: null } });
    } catch (err) {
      if (!/cancel/i.test(String(err && (err.message || err)))) {
        const inp = document.getElementById('replayfile'); if (inp) inp.click();
      }
    }
  }

  const [showSettings, setShowSettings] = useState(false);
  const [histTab, setHistTab] = useState('all');

  function handleChange(e) {
    const picked = e.target.files && e.target.files[0];
    if (picked && !/\.hbr2$/i.test(picked.name)) {
      openModal('El archivo debe tener formato .hbr2', 'darkred', 4);
      e.target.value = null;
      return;
    }
    if (picked) {
      saveReplayFile(picked)
        .then((id) => { setHistoryTick((t) => t + 1); if (id) openSaved(id); else legacyOpen(e); })
        .catch(() => legacyOpen(e));
      return;
    }
    legacyOpen(e);
  }

  function legacyOpen(e) {
    window.__fenixCurrentId = null;
    dispatch(setUserUploaded(true));
    dispatch(setConnectHalves(false))
    dispatch(setConnectedHalves(false))
    setReplayId(null);
    waitingForSocket = true;
    waitingForStats = true;

    $(function () {

      $('.roomlist-view').animate({
        left: '-150%',
      }, { duration: 700, easing: 'swing', queue: false });

      $('#loading-screen').animate({
        left: '8vw',
      }, { duration: 700, easing: 'swing', queue: false, complete: function () { callbackFn(e) } });

    })

  }


  useEffect(() => {
    // La reproducción local no requiere consultar la IP del usuario.
  }, []);

  return (
    <>
      <div className='roomlist-view fenix-home' style={{ zIndex: 5 }}>
        <img className='fh-watermark' src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt='' aria-hidden='true' />
        <button className='fh-gear' aria-label='Configuración' onClick={() => setShowSettings(true)}>
          <svg width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><circle cx='12' cy='12' r='3' /><path d='M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z' /></svg>
        </button>
        <button className='fh-gear fh-exit' aria-label='Salir de la app' onClick={() => { if (window.__fenixAskExit) window.__fenixAskExit(); }}>
          <svg width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.2' strokeLinecap='round' strokeLinejoin='round'><path d='M12 3v9' /><path d='M6.4 6.6a8 8 0 1 0 11.2 0' /></svg>
        </button>
        <div className='fh-scroll'>
          <div className='fh-hero'>
            <img className='fh-logo' src={process.env.PUBLIC_URL + '/brand/escudo-nombre.png'} alt='Associação Esportiva Fênix' />
            <h1>REPLAY ANALIZER</h1>
            <p className='fh-tag'>Os Fênix</p>
            <div className='file-btn fh-import'>
              <label htmlFor='replayfile'>
                <svg width='22' height='22' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.4' strokeLinecap='round' strokeLinejoin='round'><path d='M12 16V4M7 9l5-5 5 5M4 20h16' /></svg>
                <span>Importar repetición</span>
              </label>
              <input id='replayfile' type='file' accept='.hbr2,application/octet-stream' data-hook='replayfile' onClick={(e) => { e.target.value = null; }} onChange={handleChange} />
            </div>
          </div>
          <section className='fh-history'>
            <div className='fh-tabs' role='tablist'>
              <button role='tab' aria-selected={histTab === 'all'} className={histTab === 'all' ? 'on' : ''} onClick={() => setHistTab('all')}><svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.2' strokeLinecap='round' strokeLinejoin='round' aria-hidden='true'><circle cx='12' cy='12' r='9' /><path d='M12 7v5l3.2 2' /></svg><span>Historial</span></button>
              <button role='tab' aria-selected={histTab === 'fav'} className={histTab === 'fav' ? 'on' : ''} onClick={() => setHistTab('fav')}><svg width='18' height='18' viewBox='0 0 24 24' fill='currentColor' aria-hidden='true'><path d='M12 3.2l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17.2 6.6 20.1l1-6.1L3.2 9.7l6.1-.9z' /></svg><span>Favoritos</span></button>
            </div>
            <HistoryList key={histTab} filter={histTab} refreshKey={historyTick} onOpen={openSaved} />
          </section>
        </div>
      </div>
      {showSettings && <SettingsSheet onClose={() => setShowSettings(false)} onCleared={() => setHistoryTick((t) => t + 1)} />}
      <ReplayFav />
      <Downloading />
      <LoadingScreen />
      {mainMode === 'stats' && <GameStats replayId={replayId} />}
      {mainMode === 'replays' && <ReplaysList />}
    </>
  );
}

export default Home;