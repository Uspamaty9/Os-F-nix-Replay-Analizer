import { useState } from "react";
import $ from 'jquery'
var timeout;
var doHideModal = false;

export function openModal(message, color) { }

function Modal() {

  const [color, setColor] = useState('black')
  const [message, setMessage] = useState('')

  openModal = function (message, color, timeouter = 3) {
    setMessage(message);
    setColor(color);
    const el = document.getElementById('modal');
    if (el) {
      el.style.visibility = 'visible';
      // forzar un reflujo para que la animación de entrada siempre se vea
      void el.offsetWidth;
      el.classList.add('show');
    }
    clearTimeout(timeout)
    timeout = setTimeout(function () {
      closeModal()
    }, (timeouter * 1000))
  }

  function closeModal() {
    const el = document.getElementById('modal');
    if (!el) return;
    el.classList.remove('show');
    clearTimeout(timeout);
    // se oculta del todo solo cuando la animación de salida terminó
    timeout = setTimeout(function () { if (!el.classList.contains('show')) el.style.visibility = 'hidden'; }, 650);
  }

  function handleHover() {
    $("#modal").css('cursor', 'pointer')
  }

  return (
    <div id="modal" onClick={closeModal} onMouseMove={handleHover} style={{ backgroundColor: color }}>
      {message}
    </div>
  );
}

export default Modal;