import { useEffect, useRef, useState } from 'react';
import { CUSTOM_SLOTS, CUSTOM_DEFAULT, hsvToRgb, slotHex, slotCss, hexToSlot } from '../settings';

const SIZE = 240;

// Círculo cromático: el ángulo es el tono y la distancia al centro la saturación; la intensidad oscurece el círculo
function drawWheel(canvas, v) {
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(SIZE, SIZE);
  const R = SIZE / 2, C = R - 0.5;
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const dx = x - C, dy = y - C, r = Math.sqrt(dx * dx + dy * dy);
      const i = (y * SIZE + x) * 4;
      if (r > R - 1) { img.data[i + 3] = 0; continue; }
      const h = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360;
      const [rr, gg, bb] = hsvToRgb(h, (r / (R - 1)) * 100, v);
      img.data[i] = rr; img.data[i + 1] = gg; img.data[i + 2] = bb;
      img.data[i + 3] = r > R - 2 ? 140 : 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}

export default function ThemeEditor({ value, onChange }) {
  const [slot, setSlot] = useState('acc');
  const cvs = useRef(null);
  const cur = value[slot];
  const [hexTxt, setHexTxt] = useState(null);

  useEffect(() => { if (cvs.current) drawWheel(cvs.current, cur.v); }, [cur.v]);

  function setHex(t) {
    setHexTxt(t);
    const c = hexToSlot(t, cur.a);
    if (c) onChange({ ...value, [slot]: c });
  }
  function set(p) { setHexTxt(null); onChange({ ...value, [slot]: { ...cur, ...p } }); }

  function pick(e) {
    const r = cvs.current.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width * 2 - 1, y = (e.clientY - r.top) / r.height * 2 - 1;
    const d = Math.min(1, Math.sqrt(x * x + y * y));
    const h = (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
    set({ h: Math.round(h), s: Math.round(d * 100) });
  }
  function down(e) { e.preventDefault(); try { e.currentTarget.setPointerCapture(e.pointerId); } catch (x) { } pick(e); e.currentTarget.dragging = true; }
  function move(e) { if (e.currentTarget.dragging) pick(e); }
  function up(e) { e.currentTarget.dragging = false; }

  const ang = cur.h * Math.PI / 180, rad = cur.s / 100 * 50;
  const mx = 50 + Math.cos(ang) * rad, my = 50 + Math.sin(ang) * rad;
  const full = hsvToRgb(cur.h, cur.s, 100);

  return (
    <div className='fs-ed'>
      <div className='fs-ed-slots'>
        {CUSTOM_SLOTS.map((s) => (
          <button type='button' key={s.id} className={'fs-ed-slot' + (slot === s.id ? ' on' : '')} onClick={() => { setSlot(s.id); setHexTxt(null); }}>
            <i style={{ background: slotCss(value[s.id]) }} />
            <span>{s.name}</span>
            <small>{slotHex(value[s.id]).toUpperCase()}</small>
          </button>
        ))}
      </div>
      <div className='fs-ed-wheel'>
        <canvas ref={cvs} width={SIZE} height={SIZE} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} />
        <i className='fs-ed-dot' style={{ left: mx + '%', top: my + '%', background: slotHex({ ...cur, v: cur.v }) }} />
      </div>
      <label className='fs-ed-row'>
        <span>Intensidad <b>{cur.v}%</b></span>
        <input type='range' min='0' max='100' value={cur.v} onChange={(e) => set({ v: Number(e.target.value) })}
          style={{ background: `linear-gradient(90deg, #000, rgb(${full.join(',')}))` }} />
      </label>
      <label className='fs-ed-row'>
        <span>Opacidad <b>{cur.a}%</b></span>
        <input type='range' min='0' max='100' value={cur.a} onChange={(e) => set({ a: Number(e.target.value) })}
          className='fs-ed-alpha' style={{ '--c': slotHex(cur) }} />
      </label>
      <div className='fs-ed-foot'>
        <span className='fs-ed-prev' style={{ '--c': slotCss(cur) }} />
        <input className='fs-ed-hex' value={hexTxt != null ? hexTxt : slotHex(cur).toUpperCase()} maxLength={7} spellCheck={false} autoCapitalize='characters' aria-label='Código hexadecimal' onChange={(e) => setHex(e.target.value)} onBlur={() => setHexTxt(null)} />
        <button type='button' className='fs-btn' onClick={() => onChange(CUSTOM_DEFAULT)}>Restablecer</button>
      </div>
    </div>
  );
}
