import { useEffect, useState } from 'react';
import { THEMES, CUSTOM_DEFAULT, MAX_CUSTOMS, customsOf, slotCss, getSettings, saveSettings } from '../settings';
import ThemeEditor from './ThemeEditor';
import { backupExport, backupImport, showGuide } from '../extras';
import { listReplays, deleteReplay, hideReplay } from '../storage/history';

function fmt(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(0) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

export default function SettingsSheet({ onClose, onCleared }) {
  const [s, setS] = useState(getSettings());
  const [info, setInfo] = useState({ n: 0, size: 0 });
  const [confirm, setConfirm] = useState(false);
  const [plus, setPlus] = useState(getSettings().theme === 'custom');
  const [renIdx, setRenIdx] = useState(-1);
  const [dirty, setDirty] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  const refresh = () => listReplays().then((l) => setInfo({ n: l.filter((m) => !m.hidden).length, size: l.reduce((a, m) => a + (m.size || 0), 0) }));
  useEffect(() => { refresh(); }, []);

  const list = customsOf(s);
  const idx = Math.min(Math.max(0, Number(s.customIdx) || 0), list.length - 1);
  const cu = list[idx] ? { ...CUSTOM_DEFAULT, ...list[idx].colors } : CUSTOM_DEFAULT;
  function addCustom() {
    if (list.length >= MAX_CUSTOMS) return;
    const n = [...list, { name: 'Personalizado ' + (list.length + 1), colors: { ...CUSTOM_DEFAULT } }];
    update({ customs: n, customIdx: n.length - 1, theme: 'custom' });
  }
  function pickCustom(i) { update({ customs: list, customIdx: i, theme: 'custom' }); }
  function nameCustom(i, name) { update({ customs: list.map((c, k) => (k === i ? { ...c, name } : c)) }); }
  function delCustom(i) {
    const n = list.filter((c, k) => k !== i);
    setRenIdx(-1);
    if (!n.length) update({ customs: n, customIdx: 0, theme: s.theme === 'custom' ? 'fenix' : s.theme });
    else update({ customs: n, customIdx: Math.min(idx, n.length - 1) });
  }
  function saveCustom() { setDirty(false); setJustSaved(true); setTimeout(() => setJustSaved(false), 1800); }
  function editColors(v) { setDirty(true); setJustSaved(false); update({ customs: list.map((c, k) => (k === idx ? { ...c, colors: v } : c)), customIdx: idx, theme: 'custom' }); }
  function update(p) { const n = { ...s, ...p }; setS(n); saveSettings(n); }
  async function clearAll() {
    const l = await listReplays();
    for (const m of l) { if (m.fav) await hideReplay(m.id); else await deleteReplay(m.id); }
    setConfirm(false); refresh(); if (onCleared) onCleared();
  }

  return (
    <div className='fs-overlay' onClick={onClose}>
      <div className='fs-sheet' onClick={(e) => e.stopPropagation()}>
        <div className='fs-head'>
          <h3>Configuración</h3>
          <button className='fs-close' onClick={onClose} aria-label='Cerrar'>✕</button>
        </div>
        <div className='fs-body'>
          <section>
            <h4>Tema</h4>
            <div className='fs-themes'>
              {THEMES.map((t) => (
                <button key={t.id} className={'fs-theme' + (s.theme === t.id ? ' on' : '')} onClick={() => update({ theme: t.id })}>
                  <span className='fs-sw' style={{ background: `linear-gradient(135deg, ${t.c[0]} 0 45%, ${t.c[1]} 45% 70%, ${t.c[2]} 70%)` }} />
                  <span>{t.name}</span>
                </button>
              ))}
              <button className={'fs-theme fs-plus' + (plus ? ' on' : '')} onClick={() => setPlus(!plus)} aria-label='Mis temas personalizados' aria-expanded={plus}>
                <span className='fs-sw fs-sw-plus'>+</span>
                <span>Mis temas</span>
              </button>
            </div>
            {plus && (
              <div className='fs-customs'>
                {list.map((c, i) => (
                  <div key={i} className={'fs-cu' + (s.theme === 'custom' && i === idx ? ' on' : '')}>
                    <button type='button' className='fs-cu-pick' onClick={() => pickCustom(i)} aria-label={'Usar ' + c.name}>
                      <span className='fs-sw' style={{ background: `linear-gradient(135deg, ${slotCss(c.colors.bg)} 0 45%, ${slotCss(c.colors.acc)} 45% 70%, ${slotCss(c.colors.card)} 70%)` }} />
                    </button>
                    {renIdx === i
                      ? <input className='fs-cu-name' autoFocus maxLength={20} defaultValue={c.name} onBlur={(e) => { nameCustom(i, e.target.value.trim() || c.name); setRenIdx(-1); }} onKeyDown={(e) => { if (e.key === 'Enter') e.target.blur(); }} />
                      : <button type='button' className='fs-cu-label' onClick={() => pickCustom(i)}>{c.name}</button>}
                    <button type='button' className='fs-cu-btn' aria-label='Cambiar nombre' onClick={() => setRenIdx(i)}><svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M12 20h9' /><path d='M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z' /></svg></button>
                    <button type='button' className='fs-cu-btn del' aria-label='Eliminar tema' onClick={() => delCustom(i)}><svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3' /></svg></button>
                  </div>
                ))}
                {list.length < MAX_CUSTOMS && <button type='button' className='fs-btn fs-cu-add' onClick={addCustom}>+ Nuevo tema ({list.length}/{MAX_CUSTOMS})</button>}
                {list.length === 0 && <p className='fs-note'>Crea hasta {MAX_CUSTOMS} temas con tus colores. Se guardan solos.</p>}
              </div>
            )}
            {s.theme === 'custom' && list.length > 0 && <>
              <ThemeEditor value={cu} onChange={editColors} />
              <button type='button' className={'fs-save' + (dirty ? ' dirty' : '') + (justSaved ? ' ok' : '')} onClick={saveCustom}>
                <svg width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.2' strokeLinecap='round' strokeLinejoin='round'>{justSaved ? <path d='M5 12.5l4.5 4.5L19 7.5' /> : <><path d='M5 4h11l3 3v13H5z' /><path d='M8 4v5h7V4M8 20v-6h8v6' /></>}</svg>
                <span>{justSaved ? '¡Tema guardado!' : dirty ? 'Guardar tema' : 'Guardar tema'}</span>
              </button>
            </>}
          </section>
          <section>
            <h4>Respaldo</h4>
            <p className='fs-note'>Guarda todo tu historial y favoritos en un archivo, para pasarlo a otro celular o recuperarlo.</p>
            <div className='fs-btnrow'>
              <button type='button' className='fs-btn' onClick={backupExport}>Crear respaldo</button>
              <button type='button' className='fs-btn' onClick={async () => { await backupImport(); refresh(); if (onCleared) onCleared(); }}>Restaurar</button>
            </div>
          </section>
          <section>
            <h4>Cómo importar</h4>
            <p className='fs-note'>Toca “Importar repetición” y elige uno o varios archivos <b>.hbr2</b> (normalmente están en Descargas). Quedan guardados en el historial para verlos sin internet.</p>
            <button type='button' className='fs-btn' onClick={() => { onClose(); setTimeout(() => showGuide(true), 250); }}>Ver la guía</button>
          </section>
          <section>
            <h4>Acerca de</h4>
            <p className='fs-note'>Replay Analyzer · Os Fênix<br />Desarrollador: Uspamaty9<br />Versión 3 · funciona sin conexión.</p>
          </section>
          <section>
            <h4>Datos</h4>
            <p className='fs-note'>{info.n} repetición(es) guardada(s) · {fmt(info.size)}</p>
            {!confirm
              ? <button className='fs-btn danger' disabled={!info.n} onClick={() => setConfirm(true)}>Borrar historial</button>
              : <div className='fs-confirm'><span>¿Borrar el historial? Los favoritos se conservan.</span><button className='fs-btn danger' onClick={clearAll}>Sí, borrar</button><button className='fs-btn' onClick={() => setConfirm(false)}>No</button></div>}
          </section>
        </div>
      </div>
    </div>
  );
}
