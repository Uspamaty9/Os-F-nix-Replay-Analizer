import { useEffect, useState } from 'react';
import { THEMES, CUSTOM_DEFAULT, slotCss, getSettings, saveSettings } from '../settings';
import ThemeEditor from './ThemeEditor';
import { backupExport, backupImport, showGuide } from '../extras';
import { listReplays, deleteReplay, hideReplay } from '../storage/history';

function fmt(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(0) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

export default function SettingsSheet({ onClose, onCleared }) {
  const [s, setS] = useState(getSettings());
  const [info, setInfo] = useState({ n: 0, size: 0 });
  const [confirm, setConfirm] = useState(false);

  const refresh = () => listReplays().then((l) => setInfo({ n: l.filter((m) => !m.hidden).length, size: l.reduce((a, m) => a + (m.size || 0), 0) }));
  useEffect(() => { refresh(); }, []);

  const cu = { ...CUSTOM_DEFAULT, ...(s.custom || {}) };
  function update(p) { const n = { ...s, ...p }; setS(n); saveSettings(n); }
  async function clearAll() {
    const l = await listReplays();
    for (const m of l) { if (m.fav) await hideReplay(m.id); else await deleteReplay(m.id); }
    setConfirm(false); refresh(); if (onCleared) onCleared();
  }

  return (
    <div className='fs-overlay' onClick={onClose}>
      <div className='fs-sheet' onClick={(e) => e.stopPropagation()}>
        <div className='fs-head'>
          <h3>Configuración</h3>
          <button className='fs-close' onClick={onClose} aria-label='Cerrar'>✕</button>
        </div>
        <div className='fs-body'>
          <section>
            <h4>Tema</h4>
            <div className='fs-themes'>
              {THEMES.map((t) => (
                <button key={t.id} className={'fs-theme' + (s.theme === t.id ? ' on' : '')} onClick={() => update({ theme: t.id })}>
                  <span className='fs-sw' style={{ background: `linear-gradient(135deg, ${t.c[0]} 0 45%, ${t.c[1]} 45% 70%, ${t.c[2]} 70%)` }} />
                  <span>{t.name}</span>
                </button>
              ))}
              <button className={'fs-theme' + (s.theme === 'custom' ? ' on' : '')} onClick={() => update({ theme: 'custom', custom: cu })}>
                <span className='fs-sw' style={{ background: `linear-gradient(135deg, ${slotCss(cu.bg)} 0 45%, ${slotCss(cu.acc)} 45% 70%, ${slotCss(cu.card)} 70%)` }} />
                <span>Personalizado</span>
              </button>
            </div>
            {s.theme === 'custom' && <ThemeEditor value={cu} onChange={(v) => update({ theme: 'custom', custom: v })} />}
          </section>
          <section>
            <h4>Respaldo</h4>
            <p className='fs-note'>Guarda todo tu historial y favoritos en un archivo, para pasarlo a otro celular o recuperarlo.</p>
            <div className='fs-btnrow'>
              <button type='button' className='fs-btn' onClick={backupExport}>Crear respaldo</button>
              <button type='button' className='fs-btn' onClick={async () => { await backupImport(); refresh(); if (onCleared) onCleared(); }}>Restaurar</button>
            </div>
          </section>
          <section>
            <h4>Cómo importar</h4>
            <p className='fs-note'>Toca “Importar repetición” y elige uno o varios archivos <b>.hbr2</b> (normalmente están en Descargas). Quedan guardados en el historial para verlos sin internet.</p>
            <button type='button' className='fs-btn' onClick={() => { onClose(); setTimeout(() => showGuide(true), 250); }}>Ver la guía</button>
          </section>
          <section>
            <h4>Acerca de</h4>
            <p className='fs-note'>Replay Analyzer · Os Fênix<br />Desarrollador: Uspamaty9<br />Versión 3 · funciona sin conexión.</p>
          </section>
          <section>
            <h4>Datos</h4>
            <p className='fs-note'>{info.n} repetición(es) guardada(s) · {fmt(info.size)}</p>
            {!confirm
              ? <button className='fs-btn danger' disabled={!info.n} onClick={() => setConfirm(true)}>Borrar historial</button>
              : <div className='fs-confirm'><span>¿Borrar el historial? Los favoritos se conservan.</span><button className='fs-btn danger' onClick={clearAll}>Sí, borrar</button><button className='fs-btn' onClick={() => setConfirm(false)}>No</button></div>}
          </section>
        </div>
      </div>
    </div>
  );
}
