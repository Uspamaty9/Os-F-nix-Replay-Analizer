import { useEffect, useState } from 'react';
import { THEMES, CUSTOM_DEFAULT, MAX_CUSTOMS, customsOf, slotCss, getSettings, saveSettings } from '../settings';
import ThemeEditor from './ThemeEditor';
import { backupExport, backupImport, showGuide } from '../extras';
import { listReplays, deleteReplay, hideReplay } from '../storage/history';

function fmt(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(0) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

export default function SettingsSheet({ onClose, onCleared }) {
  const [s, setS] = useState(getSettings());
  const [info, setInfo] = useState({ n: 0, size: 0 });
  const [confirm, setConfirm] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  const refresh = () => listReplays().then((l) => setInfo({ n: l.filter((m) => !m.hidden).length, size: l.reduce((a, m) => a + (m.size || 0), 0) }));
  useEffect(() => { refresh(); }, []);

  const list = customsOf(s);
  const idx = Math.min(Math.max(0, Number(s.customIdx) || 0), list.length - 1);
  const cu = list[idx] ? { ...CUSTOM_DEFAULT, ...list[idx].colors } : CUSTOM_DEFAULT;
  function addCustom() {
    setDirty(false);
    if (list.length >= MAX_CUSTOMS) return;
    const n = [...list, { name: 'Personalizado ' + (list.length + 1), colors: { ...CUSTOM_DEFAULT } }];
    update({ customs: n, customIdx: n.length - 1, theme: 'custom' });
  }
  function pickCustom(i) { update({ customs: list, customIdx: i, theme: 'custom' }); }
  function nameCustom(i, name) { update({ customs: list.map((c, k) => (k === i ? { ...c, name } : c)) }); }
  function delCustom(i) {
    setDirty(false);
    const n = list.filter((c, k) => k !== i);
    if (!n.length) update({ customs: n, customIdx: 0, theme: s.theme === 'custom' ? 'fenix' : s.theme });
    else update({ customs: n, customIdx: Math.min(idx, n.length - 1) });
  }
  function saveCustom() { setDirty(false); setJustSaved(true); setTimeout(() => setJustSaved(false), 1800); }
  function editColors(v) { setDirty(true); setJustSaved(false); update({ customs: list.map((c, k) => (k === idx ? { ...c, colors: v } : c)), customIdx: idx, theme: 'custom' }); }
  function update(p) { const n = { ...s, ...p }; setS(n); saveSettings(n); }
  async function clearAll() {
    const l = await listReplays();
    for (const m of l) { if (m.fav) await hideReplay(m.id); else await deleteReplay(m.id); }
    setConfirm(false); refresh(); if (onCleared) onCleared();
  }

  return (
    <div className='fs-overlay' onClick={onClose}>
      <div className='fs-sheet' onClick={(e) => e.stopPropagation()}>
        <div className='fs-head'>
          <h3>Configuración</h3>
          <button className='fs-close' onClick={onClose} aria-label='Cerrar'>✕</button>
        </div>
        <div className='fs-body'>
          <section>
            <h4>Tema</h4>
            <div className='fs-themes'>
              {THEMES.map((t) => (
                <button key={t.id} className={'fs-theme' + (s.theme === t.id ? ' on' : '')} onClick={() => update({ theme: t.id })}>
                  <span className='fs-sw' style={{ background: `linear-gradient(135deg, ${t.c[0]} 0 45%, ${t.c[1]} 45% 70%, ${t.c[2]} 70%)` }} />
                  <span>{t.name}</span>
                </button>
              ))}
              {list.map((c, i) => (
                <button key={'c' + i} type='button' className={'fs-theme' + (s.theme === 'custom' && i === idx ? ' on' : '')} onClick={() => { pickCustom(i); setDirty(false); }}>
                  <span className='fs-sw' style={{ background: `linear-gradient(135deg, ${slotCss(c.colors.bg)} 0 45%, ${slotCss(c.colors.acc)} 45% 70%, ${slotCss(c.colors.card)} 70%)` }} />
                  <span className='fs-tname'>{c.name}</span>
                </button>
              ))}
              {list.length < MAX_CUSTOMS && (
                <button className='fs-theme fs-plus' onClick={addCustom} aria-label='Crear tema personalizado'>
                  <span className='fs-sw fs-sw-plus'>+</span>
                  <span>Nuevo tema</span>
                </button>
              )}
            </div>
            {s.theme === 'custom' && list.length > 0 && <>
              <div className='fs-cu-head'>
                <input className='fs-cu-name' maxLength={20} value={list[idx].name} onChange={(e) => { nameCustom(idx, e.target.value); setDirty(true); }} onBlur={(e) => { if (!e.target.value.trim()) nameCustom(idx, 'Personalizado ' + (idx + 1)); }} aria-label='Nombre del tema' />
                <button type='button' className='fs-cu-btn del' aria-label='Eliminar tema' onClick={() => delCustom(idx)}><svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3' /></svg></button>
              </div>
              <ThemeEditor value={cu} onChange={editColors} />
              <button type='button' className={'fs-save' + (dirty ? ' dirty' : '') + (justSaved ? ' ok' : '')} onClick={saveCustom}>
                <svg width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2.2' strokeLinecap='round' strokeLinejoin='round'>{justSaved ? <path d='M5 12.5l4.5 4.5L19 7.5' /> : <><path d='M5 4h11l3 3v13H5z' /><path d='M8 4v5h7V4M8 20v-6h8v6' /></>}</svg>
                <span>{justSaved ? '¡Tema guardado!' : dirty ? 'Guardar tema' : 'Guardar tema'}</span>
              </button>
            </>}
          </section>
          <section>
            <h4>Chat de la repetición</h4>
            <button type='button' className={'fs-switch' + (s.chatClear === true ? ' on' : '')} onClick={() => update({ chatClear: !(s.chatClear === true) })} aria-pressed={s.chatClear === true}>
              <span>Fondo del chat transparente</span><i />
            </button>
            <p className='fs-note'>El chat se muestra encima de la cancha, sin fondo.</p>
          </section>
          <section>
            <h4>Respaldo</h4>
            <p className='fs-note'>Guarda todo tu historial y favoritos en un archivo, para pasarlo a otro celular o recuperarlo.</p>
            <div className='fs-btnrow'>
              <button type='button' className='fs-btn' onClick={backupExport}>Crear respaldo</button>
              <button type='button' className='fs-btn' onClick={async () => { await backupImport(); refresh(); if (onCleared) onCleared(); }}>Restaurar</button>
            </div>
          </section>
          <section>
            <h4>Cómo importar</h4>
            <p className='fs-note'>Toca “Importar repetición” y elige uno o varios archivos <b>.hbr2</b> (normalmente están en Descargas). Quedan guardados en el historial para verlos sin internet.</p>
            <button type='button' className='fs-btn' onClick={() => { onClose(); setTimeout(() => showGuide(true), 250); }}>Ver la guía</button>
          </section>
          <section>
            <h4>Acerca de</h4>
            <p className='fs-note'>Replay Analyzer · Os Fênix<br />Desarrollador: Uspamaty9<br />Versión 3 · funciona sin conexión.</p>
          </section>
          <section>
            <h4>Datos</h4>
            <p className='fs-note'>{info.n} repetición(es) guardada(s) · {fmt(info.size)}</p>
            {!confirm
              ? <button className='fs-btn danger' disabled={!info.n} onClick={() => setConfirm(true)}>Borrar historial</button>
              : <div className='fs-confirm'><span>¿Borrar el historial? Los favoritos se conservan.</span><button className='fs-btn danger' onClick={clearAll}>Sí, borrar</button><button className='fs-btn' onClick={() => setConfirm(false)}>No</button></div>}
          </section>
        </div>
      </div>
    </div>
  );
}
