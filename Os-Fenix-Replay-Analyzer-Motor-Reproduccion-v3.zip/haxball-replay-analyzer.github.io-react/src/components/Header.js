import React from "react";

function Header() {
  return (
    <div className="header">
      <img className="header-shield" src={process.env.PUBLIC_URL + '/brand/escudo.png'} alt="" />
      <span className="title">OS FÊNIX</span>
      <span className="header-subtitle">Replay Analyzer</span>
    </div>
  );
}

export default Header;
