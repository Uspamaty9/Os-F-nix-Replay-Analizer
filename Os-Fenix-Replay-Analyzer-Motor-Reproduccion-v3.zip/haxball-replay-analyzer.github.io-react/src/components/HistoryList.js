import { useCallback, useEffect, useState } from 'react';
import { listReplays, renameReplay, deleteReplay } from '../storage/history';

function fmtSize(b) {
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' KB';
  return (b / 1024 / 1024).toFixed(1) + ' MB';
}

function fmtDate(t) {
  try {
    return new Date(t).toLocaleString('es', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch (e) { return ''; }
}

export default function HistoryList({ refreshKey, onOpen }) {
  const [items, setItems] = useState(null);
  const [editing, setEditing] = useState(null); // { id, value }
  const [confirmDel, setConfirmDel] = useState(null);

  const load = useCallback(() => { listReplays().then(setItems); }, []);
  useEffect(() => { load(); }, [load, refreshKey]);

  async function saveName() {
    if (!editing) return;
    await renameReplay(editing.id, editing.value);
    setEditing(null);
    load();
  }

  async function remove(id) {
    await deleteReplay(id);
    setConfirmDel(null);
    load();
  }

  if (items === null) return null;
  if (items.length === 0) {
    return (
      <div className="fh-empty">
        <p>Todavía no hay repeticiones.</p>
        <p className="fh-empty-sub">Importa un archivo <b>.hbr2</b> y quedará guardado aquí para verlo sin internet.</p>
      </div>
    );
  }

  return (
    <ul className="fh-list">
      {items.map((it) => (
        <li key={it.id} className="fh-item">
          {editing && editing.id === it.id ? (
            <div className="fh-edit">
              <input
                autoFocus
                maxLength={60}
                value={editing.value}
                onChange={(e) => setEditing({ id: it.id, value: e.target.value })}
                onKeyDown={(e) => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditing(null); }}
                aria-label="Nuevo nombre de la repetición"
              />
              <button type="button" className="fh-ok" onClick={saveName}>Guardar</button>
              <button type="button" className="fh-cancel" onClick={() => setEditing(null)}>Cancelar</button>
            </div>
          ) : confirmDel === it.id ? (
            <div className="fh-edit">
              <span className="fh-confirm">¿Eliminar «{it.name}»?</span>
              <button type="button" className="fh-danger" onClick={() => remove(it.id)}>Eliminar</button>
              <button type="button" className="fh-cancel" onClick={() => setConfirmDel(null)}>Cancelar</button>
            </div>
          ) : (
            <>
              <button type="button" className="fh-open" onClick={() => onOpen(it.id)}>
                <span className="fh-play" aria-hidden="true">▶</span>
                <span className="fh-text">
                  <span className="fh-name">{it.name}</span>
                  <span className="fh-sub">{fmtDate(it.addedAt)} · {fmtSize(it.size)}</span>
                </span>
              </button>
              <button type="button" className="fh-icon fh-rename" aria-label={'Cambiar nombre de ' + it.name} onClick={() => setEditing({ id: it.id, value: it.name })}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
              </button>
              <button type="button" className="fh-icon fh-delete" aria-label={'Eliminar ' + it.name} onClick={() => setConfirmDel(it.id)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" /></svg>
              </button>
            </>
          )}
        </li>
      ))}
    </ul>
  );
}
