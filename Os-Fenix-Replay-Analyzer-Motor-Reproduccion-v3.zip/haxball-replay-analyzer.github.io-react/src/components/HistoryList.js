import { createPortal } from 'react-dom';
import { useCallback, useEffect, useRef, useState } from 'react';
import { shareReplay } from '../extras';
import { listReplays, renameReplay, deleteReplay, setFavorite, hideReplay } from '../storage/history';


function fmtShort(t) {
  try {
    const d = new Date(t);
    const p = (n) => (n < 10 ? '0' : '') + n;
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + p(d.getFullYear() % 100);
  } catch (e) { return ''; }
}

function fmtDur(ticks) {
  const t = Math.round((ticks || 0) / 60);
  const m = Math.floor(t / 60), sec = t % 60;
  return m + ':' + (sec < 10 ? '0' : '') + sec;
}

function norm(x) {
  return String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

const SORT_KEY = 'fenix-sort';
function readSort() { try { const v = localStorage.getItem(SORT_KEY); return ['new', 'long', 'name'].includes(v) ? v : 'new'; } catch (e) { return 'new'; } }
function writeSort(v) { try { localStorage.setItem(SORT_KEY, v); } catch (e) { } }

function matchLine(info) {
  return (
    <span className="fh-match" aria-label={'Rojo ' + info.red + ', Azul ' + info.blue}>
      <i className="fh-dot r" aria-hidden="true" />
      <b className="fh-tr">{info.red}</b>
      <span className="fh-vs" aria-hidden="true">–</span>
      <b className="fh-tb">{info.blue}</b>
      <i className="fh-dot b" aria-hidden="true" />
    </span>
  );
}

function detailLine(it) {
  const info = it.info;
  const parts = [];
  if (info) {
    parts.push('⏱ ' + fmtDur(info.ticks));
    if (info.parts > 1) parts.push(info.parts + ' partidos');
  }
  return parts;
}

export default function HistoryList({ refreshKey, onOpen, filter = 'all' }) {
  const [items, setItems] = useState(null);
  const [editing, setEditing] = useState(null); // { id, value }
  const [confirmDel, setConfirmDel] = useState(null);
  const [menuId, setMenuId] = useState(null);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState(readSort);
  const nameRef = useRef(null);
  const [nameLen, setNameLen] = useState(0);
  const MAX_NAME = 40;

  const load = useCallback(() => { listReplays().then(setItems); }, []);
  useEffect(() => { load(); }, [load, refreshKey]);
  useEffect(() => { window.addEventListener('fenix-history-changed', load); return () => window.removeEventListener('fenix-history-changed', load); }, [load]);

  async function saveName() {
    if (!editing) return;
    const v = (nameRef.current ? nameRef.current.value : editing.value).slice(0, MAX_NAME);
    await renameReplay(editing.id, v);
    setEditing(null);
    load();
  }

  async function remove(it) {
    if (filter !== 'fav' && it.fav) await hideReplay(it.id); else await deleteReplay(it.id);
    setConfirmDel(null);
    load();
  }

  if (items === null) return null;
  const base = filter === 'fav' ? items.filter((i) => i.fav) : items.filter((i) => !i.hidden);
  const showTools = base.length >= 5;
  const q = norm(query.trim());
  let shown = base;
  if (showTools && q) {
    shown = base.filter((i) => norm([i.name, i.fileName, i.info && i.info.stadium, ...((i.info && i.info.redNames) || []), ...((i.info && i.info.blueNames) || [])].join(' ')).includes(q));
  }
  if (showTools && sort === 'long') shown = [...shown].sort((a, b) => ((b.info && b.info.ticks) || -1) - ((a.info && a.info.ticks) || -1));
  else if (showTools && sort === 'name') shown = [...shown].sort((a, b) => String(a.name).localeCompare(String(b.name), 'es', { sensitivity: 'base' }));
  const summary = base.length + (base.length === 1 ? ' repetición' : ' repeticiones');
  if (base.length === 0 && filter === 'fav') {
    return (
      <div className="fh-empty">
        <p>Aún no tienes favoritos.</p>
        <p className="fh-empty-sub">Toca la ⭐ en una repetición para guardarla aquí.</p>
      </div>
    );
  }
  if (base.length === 0) {
    return (
      <div className="fh-empty">
        <p>Todavía no hay repeticiones.</p>
        <p className="fh-empty-sub">Importa un archivo <b>.hbr2</b> y quedará guardado aquí para verlo sin internet.</p>
      </div>
    );
  }

  return (
    <>
    {editing && createPortal(
      <div className="fh-rename-overlay" onClick={() => setEditing(null)}>
        <div className="fh-edit fh-rename-box" onClick={(e) => e.stopPropagation()}>
          <h3>Cambiar nombre</h3>
          <input
            ref={nameRef}
            autoFocus
            maxLength={MAX_NAME}
            defaultValue={String(editing.value || '').slice(0, MAX_NAME)}
            onChange={(e) => setNameLen(e.target.value.length)}
            onFocus={(e) => { try { e.target.select(); } catch (x) { } }}
            onKeyDown={(e) => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditing(null); }}
            aria-label="Nuevo nombre de la repetición"
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
          />
          <div className={'fh-rename-count' + (nameLen >= MAX_NAME ? ' full' : '')}>{nameLen}/{MAX_NAME} caracteres</div>
          <div className="fh-rename-actions">
            <button type="button" className="fh-ok" onClick={saveName}>Guardar</button>
            <button type="button" className="fh-cancel" onClick={() => setEditing(null)}>Cancelar</button>
          </div>
        </div>
      </div>,
      document.body
    )}
    {showTools && (
      <div className="fh-tools">
        <input
          type="search"
          className="fh-search"
          placeholder="Buscar por nombre, jugador o estadio"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Buscar repeticiones"
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
        />
        <select className="fh-sort" value={sort} onChange={(e) => { setSort(e.target.value); writeSort(e.target.value); }} aria-label="Ordenar repeticiones">
          <option value="new">Más nueva</option>
          <option value="long">Más larga</option>
          <option value="name">Nombre</option>
        </select>
      </div>
    )}
    {shown.length === 0 && <div className="fh-empty fh-noresult"><p>Sin resultados para «{query}».</p></div>}
    <ul className="fh-list">
      {shown.map((it) => (
        <li key={it.id} className={'fh-item' + (menuId === it.id ? ' menu-open' : '')}>
          {confirmDel === it.id ? (
            <div className="fh-edit">
              <span className="fh-confirm">{filter !== 'fav' && it.fav ? <>¿Quitar «{it.name}» del historial? Seguirá en Favoritos.</> : <>¿Eliminar «{it.name}»?</>}</span>
              <button type="button" className="fh-danger" onClick={() => remove(it)}>{filter !== 'fav' && it.fav ? 'Quitar' : 'Eliminar'}</button>
              <button type="button" className="fh-cancel" onClick={() => setConfirmDel(null)}>Cancelar</button>
            </div>
          ) : (
            <>
              <button type="button" className="fh-open" onClick={() => onOpen(it.id)}>
                <span className="fh-play" aria-hidden="true">▶</span>
                <span className="fh-text">
                  <span className="fh-name">{it.name}</span>
                  <span className="fh-sub fh-detail">
                    {(it.info
                      ? [it.info.stadium ? '🏟 ' + it.info.stadium : null, ...detailLine(it), fmtShort(it.addedAt)].filter(Boolean)
                      : [fmtShort(it.addedAt), 'Sin analizar']
                    ).map((seg, i, arr) => <span key={i} className={'fh-seg' + (seg === 'Sin analizar' ? ' fh-new' : '')}>{seg}{i < arr.length - 1 ? ' ·' : ''}</span>)}
                  </span>
                </span>
                {it.info && matchLine(it.info)}
              </button>
              <button type="button" className={'fh-icon fh-more' + (it.fav ? ' fav' : '')} aria-label={'Más opciones de ' + it.name} aria-expanded={menuId === it.id} onClick={() => setMenuId(menuId === it.id ? null : it.id)}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="12" cy="19" r="2" /></svg>
              </button>
              {menuId === it.id && (
                <>
                  <div className="fh-menu-back" onClick={() => setMenuId(null)} />
                  <div className="fh-menu" role="menu">
                  <button type="button" className={'fh-icon fh-star' + (it.fav ? ' on' : '')} aria-label={it.fav ? 'Quitar de favoritos' : 'Agregar a favoritos'} onClick={() => { setMenuId(null); setFavorite(it.id, !it.fav); }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill={it.fav ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><path d="M12 3.2l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17.2 6.6 20.1l1-6.1L3.2 9.7l6.1-.9z" /></svg>
              </button>
                  <button type="button" className="fh-icon fh-share" aria-label={'Compartir ' + it.name} onClick={() => { setMenuId(null); shareReplay(it.id); }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="M8.6 10.6l6.8-4M8.6 13.4l6.8 4" /></svg>
              </button>
                  <button type="button" className="fh-icon fh-rename" aria-label={'Cambiar nombre de ' + it.name} onClick={() => { setMenuId(null); setNameLen(Math.min(MAX_NAME, String(it.name || '').length)); setEditing({ id: it.id, value: it.name }); }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
              </button>
                  <button type="button" className="fh-icon fh-delete" aria-label={'Eliminar ' + it.name} onClick={() => { setMenuId(null); setConfirmDel(it.id); }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" /></svg>
              </button>
                  </div>
                </>
              )}
            </>
          )}
        </li>
      ))}
    </ul>
    <p className="fh-summary">{summary}</p>
    </>
  );
}
