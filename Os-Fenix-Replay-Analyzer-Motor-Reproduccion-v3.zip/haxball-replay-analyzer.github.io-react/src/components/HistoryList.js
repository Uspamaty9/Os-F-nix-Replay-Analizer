import { createPortal } from 'react-dom';
import { useCallback, useEffect, useRef, useState } from 'react';
import { listReplays, renameReplay, deleteReplay, setFavorite, hideReplay } from '../storage/history';

function fmtSize(b) {
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' KB';
  return (b / 1024 / 1024).toFixed(1) + ' MB';
}

function fmtDate(t) {
  try {
    return new Date(t).toLocaleString('es', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch (e) { return ''; }
}

export default function HistoryList({ refreshKey, onOpen, filter = 'all' }) {
  const [items, setItems] = useState(null);
  const [editing, setEditing] = useState(null); // { id, value }
  const [confirmDel, setConfirmDel] = useState(null);
  const nameRef = useRef(null);
  const [nameLen, setNameLen] = useState(0);
  const MAX_NAME = 40;

  const load = useCallback(() => { listReplays().then(setItems); }, []);
  useEffect(() => { load(); }, [load, refreshKey]);
  useEffect(() => { window.addEventListener('fenix-history-changed', load); return () => window.removeEventListener('fenix-history-changed', load); }, [load]);

  async function saveName() {
    if (!editing) return;
    const v = (nameRef.current ? nameRef.current.value : editing.value).slice(0, MAX_NAME);
    await renameReplay(editing.id, v);
    setEditing(null);
    load();
  }

  async function remove(it) {
    if (filter !== 'fav' && it.fav) await hideReplay(it.id); else await deleteReplay(it.id);
    setConfirmDel(null);
    load();
  }

  if (items === null) return null;
  const shown = filter === 'fav' ? items.filter((i) => i.fav) : items.filter((i) => !i.hidden);
  if (shown.length === 0 && filter === 'fav') {
    return (
      <div className="fh-empty">
        <p>Aún no tienes favoritos.</p>
        <p className="fh-empty-sub">Toca la ⭐ en una repetición para guardarla aquí.</p>
      </div>
    );
  }
  if (shown.length === 0) {
    return (
      <div className="fh-empty">
        <p>Todavía no hay repeticiones.</p>
        <p className="fh-empty-sub">Importa un archivo <b>.hbr2</b> y quedará guardado aquí para verlo sin internet.</p>
      </div>
    );
  }

  return (
    <>
    {editing && createPortal(
      <div className="fh-rename-overlay" onClick={() => setEditing(null)}>
        <div className="fh-edit fh-rename-box" onClick={(e) => e.stopPropagation()}>
          <h3>Cambiar nombre</h3>
          <input
            ref={nameRef}
            autoFocus
            maxLength={MAX_NAME}
            defaultValue={String(editing.value || '').slice(0, MAX_NAME)}
            onChange={(e) => setNameLen(e.target.value.length)}
            onFocus={(e) => { try { e.target.select(); } catch (x) { } }}
            onKeyDown={(e) => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditing(null); }}
            aria-label="Nuevo nombre de la repetición"
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
          />
          <div className={'fh-rename-count' + (nameLen >= MAX_NAME ? ' full' : '')}>{nameLen}/{MAX_NAME} caracteres</div>
          <div className="fh-rename-actions">
            <button type="button" className="fh-ok" onClick={saveName}>Guardar</button>
            <button type="button" className="fh-cancel" onClick={() => setEditing(null)}>Cancelar</button>
          </div>
        </div>
      </div>,
      document.body
    )}
    <ul className="fh-list">
      {shown.map((it) => (
        <li key={it.id} className="fh-item">
          {confirmDel === it.id ? (
            <div className="fh-edit">
              <span className="fh-confirm">{filter !== 'fav' && it.fav ? <>¿Quitar «{it.name}» del historial? Seguirá en Favoritos.</> : <>¿Eliminar «{it.name}»?</>}</span>
              <button type="button" className="fh-danger" onClick={() => remove(it)}>{filter !== 'fav' && it.fav ? 'Quitar' : 'Eliminar'}</button>
              <button type="button" className="fh-cancel" onClick={() => setConfirmDel(null)}>Cancelar</button>
            </div>
          ) : (
            <>
              <button type="button" className="fh-open" onClick={() => onOpen(it.id)}>
                <span className="fh-play" aria-hidden="true">▶</span>
                <span className="fh-text">
                  <span className="fh-name">{it.name}</span>
                  <span className="fh-sub">{fmtDate(it.addedAt)} · {fmtSize(it.size)}</span>
                </span>
              </button>
              <button type="button" className={'fh-icon fh-star' + (it.fav ? ' on' : '')} aria-label={it.fav ? 'Quitar de favoritos' : 'Agregar a favoritos'} onClick={() => setFavorite(it.id, !it.fav)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill={it.fav ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><path d="M12 3.2l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17.2 6.6 20.1l1-6.1L3.2 9.7l6.1-.9z" /></svg>
              </button>
              <button type="button" className="fh-icon fh-rename" aria-label={'Cambiar nombre de ' + it.name} onClick={() => { setNameLen(Math.min(MAX_NAME, String(it.name || '').length)); setEditing({ id: it.id, value: it.name }); }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
              </button>
              <button type="button" className="fh-icon fh-delete" aria-label={'Eliminar ' + it.name} onClick={() => setConfirmDel(it.id)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" /></svg>
              </button>
            </>
          )}
        </li>
      ))}
    </ul>
    </>
  );
}
