import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './mobile.scss';
import './home.scss';
import './theme.scss';
import { applySettings } from './settings';
import store from './store';
import { Provider } from 'react-redux';

applySettings();
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
