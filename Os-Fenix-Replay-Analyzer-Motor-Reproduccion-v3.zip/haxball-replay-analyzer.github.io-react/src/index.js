import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './mobile.scss';
import './home.scss';
import './theme.scss';
import { applySettings } from './settings';
import store from './store';
import { Provider } from 'react-redux';

applySettings();
document.addEventListener('contextmenu', (e) => { const t = e.target; if (!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'))) e.preventDefault(); });
document.addEventListener('selectstart', (e) => { const t = e.target && e.target.nodeType === 1 ? e.target : (e.target && e.target.parentElement); if (!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'))) e.preventDefault(); });
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
