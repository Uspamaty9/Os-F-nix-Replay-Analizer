// Grabación de la cancha (el partido) y guardado en la galería
import { toast } from './extras';

function cap() {
  const c = window.Capacitor;
  return c && c.isNativePlatform && c.isNativePlatform() && c.nativePromise ? c : null;
}

let st = null;
const listeners = [];
export function onRecChange(fn) { listeners.push(fn); }
function notify() { listeners.forEach((f) => { try { f(); } catch (e) { } }); }
export function isRecording() { return !!st; }
export function recSeconds() { return st ? Math.floor((Date.now() - st.t0) / 1000) : 0; }

function pickMime() {
  const list = ['video/mp4;codecs=avc1.640033', 'video/mp4;codecs=avc1.64002A', 'video/mp4;codecs=avc1.42E01E', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
  for (const m of list) { try { if (window.MediaRecorder && window.MediaRecorder.isTypeSupported(m)) return m; } catch (e) { } }
  return '';
}

function blobB64(blob) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(String(fr.result).split(',')[1] || '');
    fr.onerror = () => rej(fr.error);
    fr.readAsDataURL(blob);
  });
}

// Copia la cancha a un lienzo de tamaño fijo (lado largo = long px) para que el video no se corte ni se deforme si la pantalla cambia de tamaño
function makeSource(canvas, long, fps) {
  const sw = canvas.width || 1280, sh = canvas.height || 720;
  const k = long / Math.max(sw, sh);
  const W = Math.max(2, Math.round(sw * k / 2) * 2), H = Math.max(2, Math.round(sh * k / 2) * 2);
  const off = document.createElement('canvas');
  off.width = W; off.height = H;
  const ctx = off.getContext('2d', { alpha: false });
  ctx.fillStyle = '#111'; ctx.fillRect(0, 0, W, H);
  const src = { off, W, H, running: true, raf: 0 };
  let last = 0;
  const gap = 1000 / (fps || 30) - 3;
  const draw = (t) => {
    if (!src.running) return;
    src.raf = requestAnimationFrame(draw);
    if (t - last < gap) return;
    last = t;
    const cw = canvas.width, ch = canvas.height;
    if (!cw || !ch) return;
    const s = Math.min(W / cw, H / ch), dw = Math.round(cw * s), dh = Math.round(ch * s);
    const dx = Math.round((W - dw) / 2), dy = Math.round((H - dh) / 2);
    if (dw !== W || dh !== H) { ctx.fillStyle = '#111'; ctx.fillRect(0, 0, W, H); }
    try { ctx.drawImage(canvas, 0, 0, cw, ch, dx, dy, dw, dh); } catch (e) { }
  };
  src.raf = requestAnimationFrame(draw);
  src.stop = () => { src.running = false; cancelAnimationFrame(src.raf); };
  return src;
}

// Calidad fija: 1080p a 60 fps con tasa alta (fluido y nítido); si el dispositivo no puede, baja a 720p
async function pickTier(mime, aspect, wantLong, fps) {
  const tiers = [[1920, 20e6], [1280, 10e6]];
  const mc = navigator.mediaCapabilities;
  if (!mc || !mc.encodingInfo || !mime) return tiers[0];
  for (const t of tiers) {
    const w = aspect >= 1 ? t[0] : Math.round(t[0] * aspect), h = aspect >= 1 ? Math.round(t[0] / aspect) : t[0];
    try {
      const r = await mc.encodingInfo({ type: 'record', video: { contentType: mime, width: w, height: h, bitrate: t[1], framerate: fps } });
      if (r && r.supported) return t;
    } catch (e) { return tiers[0]; }
  }
  return tiers[tiers.length - 1];
}

export async function startRecord(canvas, opts) {
  if (st) return;
  if (!canvas || !canvas.captureStream || !window.MediaRecorder) { toast('Este dispositivo no permite grabar'); return; }
  const o = opts || {}, fps = o.fps || 60;
  const mime = pickMime();
  let mr, stream, source;
  try {
    const aspect = (canvas.width || 1) / (canvas.height || 1);
    const tier = await pickTier(mime, aspect, o.long || 1920, fps);
    source = makeSource(canvas, tier[0], fps);
    stream = source.off.captureStream(fps);
    const opt = { videoBitsPerSecond: tier[1] };
    if (mime) opt.mimeType = mime;
    mr = new window.MediaRecorder(stream, opt);
  } catch (e) { if (source) source.stop(); toast('No se pudo iniciar la grabación'); return; }
  const isMp4 = /mp4/.test(mr.mimeType || mime);
  const d = new Date(); const pad = (n) => String(n).padStart(2, '0');
  const name = 'OsFenix-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()) + (isMp4 ? '.mp4' : '.webm');
  const type = isMp4 ? 'video/mp4' : 'video/webm';
  const s = { mr, source, chunks: [], t0: Date.now(), name, type };
  // Sin pasar nada al sistema mientras se graba: todo queda en memoria hasta que decidas guardar
  mr.ondataavailable = (e) => { if (e.data && e.data.size) s.chunks.push(e.data); };
  st = s;
  mr.start(1000);
  document.body.classList.add('fenix-recording');
  toast('Grabando…');
  notify();
}

// Detiene la grabación y devuelve el video { blob, name, type, secs } (o null si no hay nada)
export function stopRecord() {
  const s = st;
  if (!s) return Promise.resolve(null);
  st = null;
  notify();
  document.body.classList.remove('fenix-recording');
  if (s.source) s.source.stop();
  return new Promise((resolve) => {
    s.mr.onstop = () => {
      if (!s.chunks.length) { resolve(null); return; }
      resolve({ blob: new Blob(s.chunks, { type: s.type }), name: s.name, type: s.type, secs: Math.max(1, Math.round((Date.now() - s.t0) / 1000)) });
    };
    try { s.mr.stop(); } catch (e) { resolve(null); }
  });
}

// Guarda el video en la galería (en el celular) o lo descarga (navegador)
export async function saveRecording(rec) {
  const c = cap();
  if (c) {
    await c.nativePromise('HbrScanner', 'recStart', { name: rec.name, mime: rec.type });
    try {
      const CH = 786432;
      for (let off = 0; off < rec.blob.size; off += CH) {
        await c.nativePromise('HbrScanner', 'recWrite', { data: await blobB64(rec.blob.slice(off, off + CH)) });
      }
      await c.nativePromise('HbrScanner', 'recEnd', { discard: false });
    } catch (e) {
      try { await c.nativePromise('HbrScanner', 'recEnd', { discard: true }); } catch (x) { }
      throw e;
    }
    return;
  }
  const url = URL.createObjectURL(rec.blob);
  const a = document.createElement('a'); a.href = url; a.download = rec.name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); if (a.parentNode) a.parentNode.removeChild(a); }, 2000);
}

// Ventana con el video para verlo y decidir si guardarlo
export function showRecordingPreview(rec) {
  if (!rec) { toast('No se grabó nada'); return; }
  closePreview(true);
  const url = URL.createObjectURL(rec.blob);
  const mb = (rec.blob.size / 1048576).toFixed(1);
  const o = document.createElement('div');
  o.className = 'fenix-rec-preview';
  o.innerHTML = '<div class="frp-box"><div class="frp-top"><div class="fx-badge ok"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div><div class="frp-tt"><h3>Tu grabaci\u00f3n</h3><div class="frp-chips"><span>' + Math.floor(rec.secs / 60) + ':' + ('0' + (rec.secs % 60)).slice(-2) + '</span><span>' + mb + ' MB</span><span>1080p \u00b7 60 fps</span></div></div></div>' +
    '<video class="frp-video" controls playsinline loop muted autoplay></video>' +
    '<p class="frp-ask">\u00bfQuieres guardarla en tu galer\u00eda?</p>' +
    '<div class="frp-btns"><button type="button" class="frp-del"><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg><span>Descartar</span></button><button type="button" class="frp-save"><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg><span>Guardar</span></button></div></div>';
  const v = o.querySelector('video');
  v.src = url;
  o.__url = url;
  o.addEventListener('pointerdown', (e) => e.stopPropagation());
  o.addEventListener('click', async (e) => {
    e.stopPropagation();
    const t = e.target;
    const del = t.closest && t.closest('.frp-del'), sv = t.closest && t.closest('.frp-save');
    if (del) { closePreview(); return; }
    if (sv) {
      if (o.classList.contains('busy')) return;
      o.classList.add('busy'); const lb = sv.querySelector('span'); lb.textContent = 'Guardando…';
      try { await saveRecording(rec); toast(cap() ? 'Video guardado en la galería' : 'Video descargado'); closePreview(); }
      catch (err) { o.classList.remove('busy'); lb.textContent = 'Reintentar'; toast('No se pudo guardar el video'); }
    }
  });
  document.body.appendChild(o);
}
export function closePreview(now) {
  Array.prototype.forEach.call(document.querySelectorAll('.fenix-rec-preview'), (o) => {
    const kill = () => { try { const v = o.querySelector('video'); if (v) { v.pause(); v.removeAttribute('src'); v.load(); } } catch (e) { } if (o.__url) URL.revokeObjectURL(o.__url); if (o.parentNode) o.parentNode.removeChild(o); };
    if (now) kill(); else { o.classList.add('out'); setTimeout(kill, 130); }
  });
}
export function previewOpen() { return !!document.querySelector('.fenix-rec-preview:not(.out)'); }
