// Grabación de la cancha (el partido) y guardado en la galería
import { toast } from './extras';

function cap() {
  const c = window.Capacitor;
  return c && c.isNativePlatform && c.isNativePlatform() && c.nativePromise ? c : null;
}

let st = null;
const listeners = [];
export function onRecChange(fn) { listeners.push(fn); }
function notify() { listeners.forEach((f) => { try { f(); } catch (e) { } }); }
export function isRecording() { return !!st; }
export function recSeconds() { return st ? Math.floor((Date.now() - st.t0) / 1000) : 0; }

function pickMime() {
  const list = ['video/mp4;codecs=avc1.42E01E', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
  for (const m of list) { try { if (window.MediaRecorder && window.MediaRecorder.isTypeSupported(m)) return m; } catch (e) { } }
  return '';
}

function b64(buf) {
  const u = new Uint8Array(buf); let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}

export async function startRecord(canvas) {
  if (st) return;
  if (!canvas || !canvas.captureStream || !window.MediaRecorder) { toast('Este dispositivo no permite grabar'); return; }
  const mime = pickMime();
  let mr, stream;
  try {
    stream = canvas.captureStream(30);
    const opt = { videoBitsPerSecond: 5000000 };
    if (mime) opt.mimeType = mime;
    mr = new window.MediaRecorder(stream, opt);
  } catch (e) { toast('No se pudo iniciar la grabación'); return; }
  const isMp4 = /mp4/.test(mr.mimeType || mime);
  const d = new Date(); const pad = (n) => String(n).padStart(2, '0');
  const name = 'OsFenix-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()) + (isMp4 ? '.mp4' : '.webm');
  const type = isMp4 ? 'video/mp4' : 'video/webm';
  const c = cap();
  const s = { mr, chunks: [], t0: Date.now(), native: !!c, q: Promise.resolve(), name, type, err: false };
  if (c) {
    try { await c.nativePromise('HbrScanner', 'recStart', { name, mime: type }); } catch (e) { toast('No se pudo guardar en la galería'); return; }
  }
  mr.ondataavailable = (e) => {
    if (!e.data || !e.data.size) return;
    if (s.native) s.q = s.q.then(() => e.data.arrayBuffer()).then((buf) => c.nativePromise('HbrScanner', 'recWrite', { data: b64(buf) })).catch(() => { s.err = true; });
    else s.chunks.push(e.data);
  };
  st = s;
  mr.start(1000);
  toast('Grabando…');
  notify();
}

export function stopRecord() {
  const s = st;
  if (!s) return Promise.resolve();
  st = null;
  notify();
  return new Promise((resolve) => {
    s.mr.onstop = async () => {
      try {
        await s.q;
        if (s.native) {
          const c = cap();
          await c.nativePromise('HbrScanner', 'recEnd', { discard: s.err });
          toast(s.err ? 'No se pudo guardar el video' : 'Video guardado en la galería');
        } else {
          const url = URL.createObjectURL(new Blob(s.chunks, { type: s.type }));
          const a = document.createElement('a'); a.href = url; a.download = s.name; document.body.appendChild(a); a.click();
          setTimeout(() => { URL.revokeObjectURL(url); if (a.parentNode) a.parentNode.removeChild(a); }, 2000);
          toast('Video descargado');
        }
      } catch (e) { toast('No se pudo guardar el video'); }
      resolve();
    };
    try { s.mr.stop(); } catch (e) { resolve(); }
  });
}
