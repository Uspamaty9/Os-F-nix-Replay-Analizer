// Transición entre pantallas: telón con el escudo que entra y sale
export function fenixTransition(hold = 520) {
  try {
    const old = document.querySelector('.fenix-trans');
    if (old && old.parentNode) old.parentNode.removeChild(old);
    const d = document.createElement('div');
    d.className = 'fenix-trans';
    d.innerHTML = '<div class="ft-glow"></div><img src="' + (process.env.PUBLIC_URL || '') + '/brand/escudo.png" alt="" /><i class="ft-line"></i>';
    document.body.appendChild(d);
    requestAnimationFrame(() => d.classList.add('in'));
    setTimeout(() => d.classList.add('out'), hold);
    setTimeout(() => { if (d.parentNode) d.parentNode.removeChild(d); }, hold + 520);
  } catch (e) { }
}
