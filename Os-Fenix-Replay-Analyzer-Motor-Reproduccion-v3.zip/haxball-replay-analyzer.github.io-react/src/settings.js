const KEY = 'fenix-settings';
export const THEMES = [
  { id: 'fenix', name: 'Fênix', c: ['#7A0E1A', '#C89A3D', '#111111'] },
  { id: 'oscuro', name: 'Oscuro', c: ['#0d0d0d', '#5AA9FF', '#1c1c1c'] },
  { id: 'claro', name: 'Claro', c: ['#F7F3E8', '#7A0E1A', '#ffffff'] },
  { id: 'medianoche', name: 'Medianoche', c: ['#0B1630', '#35D0C8', '#14264d'] },
  { id: 'bosque', name: 'Bosque', c: ['#0E1F14', '#8BC34A', '#17301f'] },
];
export function getSettings() {
  try { return { theme: 'fenix', chat: true, arrows: true, ...(JSON.parse(localStorage.getItem(KEY)) || {}) }; } catch (e) { return { theme: 'fenix', chat: true }; }
}
export function saveSettings(s) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { }
  applySettings(s);
}
export function applySettings(s = getSettings()) {
  const b = document.body;
  if (!b) return;
  if (s.theme && s.theme !== 'fenix') b.setAttribute('data-theme', s.theme); else b.removeAttribute('data-theme');
  b.classList.toggle('fenix-nochat', s.chat === false);
  window.__fenixArrows = s.arrows !== false;
}
