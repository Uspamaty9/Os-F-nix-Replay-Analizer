// Datos del club que salen al azar en la pantalla "Analizando"
export const FACTS = [
  '¿Sabías que Os Fênix nació indirectamente de solo un grupo de WhatsApp de 3 personas?',
  '¿Sabías que las 3 personas que fundaron indirectamente Os Fênix son Juan Velázquez (Jusevemo), Héctor Chávez (Today Vargas) y Mathias Lara (Uspamaty9)?',
  '¿Sabías que Os Fênix se fundó el 8 de julio del 2026 (08/07/26)?',
  '¿Sabías que Os Fênix tiene TikTok? ¡Síguenos!',
  '¿Sabías que el lema del club es "Do fogo nasce a Vitoria", que en español es: del fuego nace la victoria?',
  '¿Sabías que en las primeras versiones de Os Fênix los colores del club eran rojo y azul, y no rojo y negro como lo conocemos hoy?',
  '¿Sabías que el primer director técnico del club fue Bernew Smchtar?',
  '¿Sabías que el primer y único presidente del club (hasta ahora) ha sido Uspamaty9?',
  '¿Sabías que el nombre completo de Os Fênix es: Associação Esportiva Fênix?',
  '¿Sabías que en un partido amistoso que se fue a penales, no metimos ningún penal?',
  '¿Sabías que hasta ahora Os Fênix no tiene ningún título oficial? ¡Seguimos luchando!',
  '¿Sabías que el título más cercano que hemos estado de ganar ha sido el Mundial?',
  '¿Sabías que estuvimos cerca de conseguir un título, pero quedamos en semifinales porque no se siguió el torneo (Mundial)?',
  '¿Sabías que puedes ayudarnos a mejorar la app? Coméntale a Uspa y te escuchará.',
  '¿Sabías que esta app se hizo en una semana?',
];

let last = -1;
export function randomFact() {
  let i = Math.floor(Math.random() * FACTS.length);
  if (FACTS.length > 1 && i === last) i = (i + 1) % FACTS.length;
  last = i;
  return FACTS[i];
}
