// Datos del club que salen al azar en la pantalla "Analizando"
export const FACTS = [
  '¿Sabías que Os Fênix nació, indirectamente, de un grupo de WhatsApp de solo 3 personas?',
  '¿Sabías que sus fundadores son Juan Velázquez (Jusevemo), Héctor Chávez (Today Vargas) y Mathias Lara (Uspamaty9)?',
  '¿Sabías que Os Fênix se fundó el 8 de julio de 2026 (08/07/26)?',
  '¿Sabías que Os Fênix tiene TikTok? ¡Síguenos!',
  '¿Sabías que el lema del club es "Do fogo nasce a Vitória", que en español significa "Del fuego nace la victoria"?',
  '¿Sabías que en las primeras versiones del club los colores eran rojo y azul, y no rojo y negro como hoy?',
  '¿Sabías que el primer director técnico del club fue Bernew Smchtar?',
  '¿Sabías que el primer y único presidente del club, hasta ahora, es Uspamaty9?',
  '¿Sabías que el nombre completo del club es Associação Esportiva Fênix?',
  '¿Sabías que en un amistoso que se definió por penales no metimos ni uno?',
  '¿Sabías que Os Fênix aún no tiene ningún título oficial? ¡Seguimos luchando!',
  '¿Sabías que lo más cerca que hemos estado de un título fue en el Mundial? Quedamos en semifinales y el torneo no continuó.',
  '¿Sabías que puedes ayudarnos a mejorar la app? Cuéntaselo a Uspamaty9 y te escuchará.',
  '¿Sabías que esta app se hizo en una semana?',
];

let last = -1;
export function randomFact() {
  let i = Math.floor(Math.random() * FACTS.length);
  if (FACTS.length > 1 && i === last) i = (i + 1) % FACTS.length;
  last = i;
  return FACTS[i];
}
