# Os Fênix Replay Analyzer — motor de reproducción integrado

Esta versión parte del código fuente de HaxBall Replay Analyzer proporcionado por el usuario. Conserva `src/game2.js`, que incluye el motor original de lectura/reproducción de `.hbr2`, el renderizado del campo, los controles de reproducción y el análisis estadístico.

## Estado
- Integrado en el proyecto React: motor de replay de `src/game2.js` y su conexión con la interfaz/estadísticas.
- Interfaz rebrandeada con identidad Os Fênix y paleta negro, rojo oscuro y dorado.
- La carga local ya no intenta enviar automáticamente el archivo `.hbr2` al servidor de estadísticas.
- El proyecto es código fuente. No incluye APK ni instalador de Windows compilado.
- No se pudo ejecutar un build de producción en este entorno porque el ZIP no contiene `node_modules` y no se ha validado una instalación de dependencias.
- Aunque el análisis del archivo se procesa en el cliente, esta base heredada puede hacer solicitudes a recursos web auxiliares del motor; por tanto, el funcionamiento 100 % sin internet todavía debe comprobarse.

## Ejecutar para desarrollo
Requiere Node.js compatible con Create React App.

```bash
npm install
npm start
```

Abre la app, pulsa **Load replay / Cargar repetición** y selecciona un archivo `.hbr2`. Los controles de reproducción (play/pausa, reinicio, velocidad y barra de tiempo) pertenecen al motor heredado.

## Créditos
Motor base: HaxBall Replay Analyzer, repositorio proporcionado por el usuario. Conservar la licencia original `LICENSE.MD`.
